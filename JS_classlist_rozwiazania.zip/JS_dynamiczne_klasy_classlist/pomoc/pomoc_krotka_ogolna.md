# Pomoc ogólna: Dynamiczne zarządzanie klasami CSS (`classList`)

Przedmiot: **Programowanie aplikacji internetowych (160h)**  
Semestr: **3 — JavaScript w Przeglądarce: DOM, Zdarzenia i BOM**  
Moduł: **04 — Dynamiczne zarządzanie klasami CSS (`classList`)**

---

## 1. Struktura katalogu zadania

W każdym folderze zadania (`zadanie_01` do `zadanie_08`) znajdują się dwa obszary pracy:

| Lokalizacja | Rola pliku | Zasady edycji przez ucznia |
|:------------|:-----------|:---------------------------|
| Folder zadania (`zadanie_XX/`) | Szablon startowy (`index.html`, `style.css`, `script.js`) | Tutaj uczeń pisze własny kod. W pliku `script.js` znajdują się komentarze z zadaniami do samodzielnego uzupełnienia. |
| Podfolder `rozwiazanie/` | Kompletne, wzorcowe rozwiązanie zadania | Służy do autokontroli po zakończeniu samodzielnej pracy lub weryfikacji działania w przypadku trudności. |

---

## 2. Ściąga składniowa metod obiektu `classList`

Pobranie elementu:
```javascript
const el = document.querySelector('#id-elementu');
```

Zestawienie metod:

| Metoda | Przykład użycia | Opis działania | Co zwraca? |
|:-------|:----------------|:---------------|:-----------|
| `add(klasa, ...)` | `el.classList.add('aktywny');` | Dodaje jedną lub więcej klas do elementu. Ignoruje duplikaty. | `undefined` |
| `remove(klasa, ...)` | `el.classList.remove('ukryty');` | Usuwa podane klasy z elementu. Bezpieczna, gdy klasy nie ma. | `undefined` |
| `toggle(klasa)` | `el.classList.toggle('otwarty');` | Usuwa klasę jeśli istnieje, dodaje jeśli jej nie ma. | `boolean` (stan po zmianie) |
| `toggle(klasa, warunek)` | `el.classList.toggle('blad', x < 0);` | Wymusza dodanie (gdy `true`) lub usunięcie (gdy `false`). | `boolean` |
| `contains(klasa)` | `el.classList.contains('aktywny')` | Sprawdza, czy element ma daną klasę. | `boolean` (`true`/`false`) |
| `replace(stara, nowa)` | `el.classList.replace('ladowanie', 'gotowe');` | Zamienia `stara` na `nowa`, o ile `stara` istnieje. | `boolean` |

---

## 3. Kamień milowy (Zadanie 8 — Portal Usługowy): Kontrakt identyfikatorów DOM

W Zadaniu 8 Capstone przygotowujemy interaktywny portal z panelem bocznym i konfiguracją zamówienia. Obowiązuje ścisły kontrakt identyfikatorów i klas:

- Pola formularza: `#imie`, `#nazwisko`, `#email`, `#usluga`, `#ilosc`, `#regulamin`
- Przyciski akcji: `#btn-menu`, `#btn-motyw`, `#btn-zamow`, `#btn-reset`
- Wyjścia i komunikaty: `#podsumowanie`, `#komunikat-status`
- Klasy stanów: `.aktywny`, `.ukryty`, `.blad-walidacji`, `.sukces-walidacji`, `.ciemny-motyw`

---

## 4. Szybkie przypomnienie techniczne (Fast Track)

1. **Konsola przeglądarki (F12):** Przed zgłoszeniem problemu zawsze otwórz konsolę deweloperską (`Ctrl + Shift + I` lub `F12` -> zakładka *Console*). Jeśli nazwa zmiennej lub selektora ma literówkę, w konsoli pojawi się czerwony komunikat z numerem linii błędu.
2. **Kropka w selektorze vs brak kropki w `classList`:**  
   - W `querySelector('.moja-klasa')` kropka jest **obowiązkowa**, bo określa selektor klasy CSS.
   - W `classList.add('moja-klasa')` kropki **nie wolno stawiać**, ponieważ metoda operuje wyłącznie na samej nazwie tokenu.
3. **Podłączanie skryptu w HTML:** Zawsze sprawdzaj, czy znacznik `<script src="script.js"></script>` znajduje się tuż przed zamykającym znacznikiem `</body>` lub posiada atrybut `defer`. Zapobiega to próbie pobrania elementu, który nie został jeszcze sparsowany przez przeglądarkę.
4. **Iteracja po grupie elementów:** Gdy pobierasz wiele przycisków przez `querySelectorAll()`, pamiętaj o pętli:
   ```javascript
   document.querySelectorAll('.przycisk').forEach(p => {
       p.addEventListener('click', () => { /* logika */ });
   });
   ```
5. **Czyste klasy semestralne:** Zamiast modyfikować `style.display = 'none'`, twórz regułę `.ukryty { display: none; }` i używaj `classList.add('ukryty')` lub `classList.remove('ukryty')`.
