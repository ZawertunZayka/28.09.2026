# Pomoc dostępna: Dynamiczne zarządzanie klasami CSS (`classList`)

Wersja materiału dydaktycznego przygotowana z myślą o uczniach preferujących jednoznaczny, dosłowny przekaz instruktażowy.

---

## 1. Słowniczek pojęć tego działu

- **Klasa CSS:** Nazwa stylu zdefiniowana w pliku CSS, która zaczyna się od kropki w arkuszu stylów (np. `.aktywny`), ale w kodzie HTML i w metodach `classList` wpisywana jest bez kropki.
- **Obiekt `classList`:** Narzędzie w JavaScript, które przechowuje wszystkie klasy przypisane do danego elementu HTML i pozwala na ich zmianę.
- **`add`:** Polecenie dodające nową klasę do elementu HTML.
- **`remove`:** Polecenie usuwające wybraną klasę z elementu HTML.
- **`toggle`:** Polecenie działające jak przełącznik światła — jeśli klasa jest dodana, zostaje usunięta; jeśli jej nie ma, zostaje dodana.
- **`contains`:** Pytanie sprawdzające, czy element posiada daną klasę, dające odpowiedź prawda (`true`) lub fałsz (`false`).
- **`replace`:** Polecenie zamieniające starą klasę na nową klasę.

---

## 2. Kolejność pracy z każdym zadaniem

Wykonuj poniższe kroki po kolei dla każdego zadania:

1. Otwórz plik `instrukcja.md` w folderze zadania i przeczytaj dokładnie treść polecenia.
2. Otwórz plik `index.html` oraz plik `style.css` w edytorze kodu, aby zobaczyć strukturę strony oraz przygotowane klasy stylów.
3. Otwórz plik `script.js` w głównym folderze zadania. Znajdź linie oznaczone komentarzem `// Twoje rozwiazanie`.
4. Napisz wymagany kod JavaScript, który pobiera elementy ze strony i zmienia ich klasy za pomocą `classList`.
5. Zapisz wszystkie pliki skrótem klawiszowym `Ctrl + S`.
6. Otwórz plik `index.html` w przeglądarce internetowej i przetestuj działanie przycisków oraz pól formularza.
7. Jeśli coś nie działa, otwórz konsolę klawiszem `F12` i sprawdź, czy nie ma błędu w pisowni zmiennych.
8. Po wykonaniu własnej próby porównaj swój kod z plikiem znajdującym się w podfolderze `rozwiazanie/`.

---

## 3. Instrukcja krok po kroku: Jak dodać klasę po kliknięciu

1. Pobierz przycisk ze strony:
   ```javascript
   const przycisk = document.querySelector('#btn-akcja');
   ```
2. Pobierz element, którego wygląd chcesz zmienić:
   ```javascript
   const ramka = document.querySelector('#ramka-info');
   ```
3. Zarejestruj zdarzenie kliknięcia:
   ```javascript
   przycisk.addEventListener('click', () => {
       // Dodajemy klasę bez kropki:
       ramka.classList.add('aktywny');
   });
   ```

---

## 4. Zasady dostępności cyfrowej (a11y) w tym dziale

1. **Etykiety pól formularza:** Każde pole `<input>` musi mieć powiązany znacznik `<label>` za pomocą atrybutu `for` równego atrybutowi `id` pola.
2. **Kontrast barw:** Zmiana klasy na `.blad-walidacji` lub `.sukces-walidacji` nie może opierać się wyłącznie na samym kolorze tekstu. Dodawaj wyraźną ramkę lub komunikat tekstowy.
3. **Elementy klikalne:** Do wywoływania akcji w JavaScript zawsze stosuj znacznik `<button>`, a nie pusty znacznik `<div>`. Przyciski można wygodnie obsługiwać klawiaturą za pomocą klawisza `Tab` oraz `Enter`.
