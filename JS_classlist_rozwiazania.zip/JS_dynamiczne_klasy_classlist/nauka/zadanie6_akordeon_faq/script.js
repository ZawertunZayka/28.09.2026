const pytania = document.querySelectorAll('.faq-pytanie');

pytania.forEach((btn) => {
  btn.addEventListener('click', () => {
    const kontener = btn.closest('.faq-element');
    kontener.classList.toggle('otwarty');
  });
});
