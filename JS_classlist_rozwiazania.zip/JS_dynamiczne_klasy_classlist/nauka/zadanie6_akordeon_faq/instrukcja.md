# Zadanie 6: Akordeon pytań i odpowiedzi (FAQ)

## Cel
Celem zadania jest utworzenie interaktywnego panelu często zadawanych pytań (FAQ) dla miejskiego przedsiębiorstwa wodociągowego z użyciem badania stanu elementu za pomocą `classList.contains()` oraz przełączania klasy `.otwarty`. Sukces zadania poznasz po tym, że kliknięcie dowolnego pytania na przemian rozwija i zwija treść odpowiedzi oraz obraca strzałkę wskaźnika.

W praktyce programistycznej mechanizm akordeonu opartego na badaniu obecności klas wykorzystywany jest do:
- Zwijania i rozwijania sekcji specyfikacji technicznej w cennikach usług telekomunikacyjnych.
- Rozwijania filtrów bocznych w katalogu produktów w sklepie meblowym.
- Prezentacji warunków umowy i regulaminów w wieloetapowych kreatorach polis ubezpieczeniowych.

## Wskazówki aktywizujące
1. Przypomnij sobie z sekcji 6 pliku `teoria.md`, jak działa metoda `classList.contains()`.
2. Zastanów się: w jaki sposób metoda `classList.toggle('otwarty')` pozwala jednym wywołaniem zrealizować zarówno rozwijanie, jak i zwijanie odpowiedzi?
3. W konsoli przeglądarki (`F12`) przetestuj:
   `document.querySelector('.faq-element').classList.contains('otwarty')`

## Treść do wpisania
Wpisz dokładnie na stronie: „Wodociągi Miejskie — Centrum Pomocy Mieszkańca” oraz pytanie „Jak zgłosić awarię przyłącza wodociągowego poza godzinami pracy urzędu?” z odpowiedzią „Pogotowie wodociągowo-kanalizacyjne dyżuruje całodobowo pod bezpłatnym numerem alarmowym 994.”. 

## Wymagania
1. W pliku `index.html` zdefiniuj listę pytań w strukturze kontenerów `.faq-element`:
   - Każdy element zawiera nagłówek przycisku `.faq-pytanie` oraz blok odpowiedzi `.faq-odpowiedz`.
   - W przycisku umieść tekst pytania oraz wskaźnik `▼`.
2. W pliku `style.css`:
   - `.faq-odpowiedz` ma domyślnie `display: none;`.
   - Gdy kontener posiada klasę `.faq-element.otwarty`, jego blok odpowiedzi przyjmuje `display: block;`, a strzałka obraca się lub zmienia kolor na `#38bdf8`.
3. W pliku `script.js`:
   - Pobierz wszystkie elementy nagłówków pytań (`.faq-pytanie`).
   - Dla każdego nagłówka podepnij zdarzenie `click`:
     - Odszukaj nadrzędny kontener pytania (użyj `pytanie.closest('.faq-element')`).
     - Przełącz na nim klasę `otwarty` za pomocą `kontener.classList.toggle('otwarty')`.

## Przykład
- **Stan początkowy:** Na stronie widoczne są 3 pytania z zamkniętymi strzałkami. Treści odpowiedzi są schowane.
- **Akcja 1:** Mieszkaniec klika pierwsze pytanie o zgłoszenie awarii.
- **Efekt 1:** Kontener otrzymuje klasę `.otwarty`, pojawia się tekst o całodobowym numerze 994, a strzałka zmienia kolor.
- **Akcja 2:** Mieszkaniec klika to samo pytanie ponownie.
- **Efekt 2:** Klasa `.otwarty` zostaje usunięta, odpowiedź ponownie znika z widoku.
