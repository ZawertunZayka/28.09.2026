# Zadanie 8: Portal Usługowy IT-Partner — Panel Konfiguracyjny

## Cel
Celem zadania jest utworzenie zintegrowanego panelu zamówień w portalu technologicznym IT-Partner, łączącego boczne menu nawigacyjne, dynamiczny podgląd warunków zamówienia oraz interaktywną walidację formularza z użyciem pełnego zestawu metod `classList`. Sukces zadania poznasz po tym, że przycisk menu płynnie wysuwa boczny panel, zmiana motywu przełącza kolorystykę portalu, a formularz dynamicznie weryfikuje poprawność danych i wylicza koszyk usług w czasie rzeczywistym.

W praktyce programistycznej budowa takiego panelu stanowi podstawę:
- Paneli zarządzania usługami hostingowymi i domenami (cPanel, Cloud Dashboard).
- Konfiguratorów wyceny wdrożeń oprogramowania dla klientów B2B.
- Formularzy zamówień w platformach e-commerce z dynamicznymi zniżkami.

## Wskazówki aktywizujące
1. Wykorzystaj całą wiedzę zdobytą w zadaniach 1–7 oraz zaleceń z `pomoc_krotka_ogolna.md` odnośnie kontraktu identyfikatorów DOM.
2. Zastanów się: jak za pomocą metody `classList.toggle('otwarty')` obsłużyć wysuwanie panelu bocznego, a za pomocą `classList.add('blad-walidacji')` i `classList.add('sukces-walidacji')` zadbać o intuicyjny feedback dla klienta?
3. W konsoli deweloperskiej (`F12`) przetestuj:
   `document.querySelector('#menu-boczne').classList.toggle('otwarty')`

## Treść do wpisania
Wpisz dokładnie na stronie: „IT-Partner Portal — Konfigurator Usług Chmurowych” oraz opcje usług „Serwer VPS SSD — 120 zł / mies.”, „Baza Danych Managed SQL — 250 zł / mies.” oraz przycisk „Przelicz i zatwierdź zamówienie”.

## Wymagania
1. W pliku `index.html` zdefiniuj:
   - Nagłówek z przyciskiem `#btn-menu` oraz `#btn-motyw`.
   - Wysuwany panel boczny `#menu-boczne` z linkami nawigacyjnymi.
   - Formularz `#formularz-zamowienia` z polami: `#imie`, `#email`, `#usluga`, `#ilosc`, `#regulamin`.
   - Przyciski akcji: `#btn-zamow` oraz `#btn-reset`.
   - Kontenery wyjścia: `#podsumowanie` oraz `#komunikat-status`.
2. W pliku `style.css`:
   - Zastosuj jasną paletę portalu (`#f1f5f9` / `#ffffff` / `#2563eb`).
   - Klasa `.ciemny-motyw` odwraca barwy na kontrastowe ciemne tło.
   - Klasa `.otwarty` na `#menu-boczne` wysuwa panel.
   - Klasy `.blad-walidacji`, `.sukces-walidacji`, `.ukryty`.
3. W pliku `script.js`:
   - Obsłuż kliknięcie `#btn-menu` przełączające klasę `.otwarty` na `#menu-boczne`.
   - Obsłuż kliknięcie `#btn-motyw` przełączające klasę `.ciemny-motyw` na `document.body`.
   - Obsłuż kliknięcie `#btn-zamow`: sprawdź, czy pola `#imie` i `#email` nie są puste, czy regulamin jest zaznaczony. Zastosuj klasy `.blad-walidacji` i `.sukces-walidacji`. Wylicz koszt (`usluga * ilosc`) i wypisz w `#podsumowanie`.
   - Obsłuż `#btn-reset`: wyczyść wartości pól, usuń wszystkie klasy walidacji i zresetuj `#podsumowanie`.

## Przykład
- **Stan początkowy:** Wyświetla się jasny portal z formularzem konfiguracji serwerów. Panel boczny jest schowany poza ekranem.
- **Akcja 1:** Klient klika przycisk „Menu boczne”.
- **Efekt 1:** Klasa `.otwarty` wysuwa panel boczny z lewej strony ekranu.
- **Akcja 2:** Klient wybiera usługę „Baza Danych Managed SQL — 250 zł / mies.”, wpisuje 3 miesiące, zaznacza regulamin i klika „Przelicz i zatwierdź zamówienie”.
- **Efekt 2:** Formularz zostaje oznaczony zielonymi ramkami sukcesu, a w `#podsumowanie` pojawia się wyliczenie: „Wycena gotowa. Łączny koszt zamówienia brutto: 750 zł”.
