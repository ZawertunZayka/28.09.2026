const menuBoczne = document.querySelector('#menu-boczne');
const btnMenu = document.querySelector('#btn-menu');
const btnMotyw = document.querySelector('#btn-motyw');
const inputImie = document.querySelector('#imie');
const inputEmail = document.querySelector('#email');
const selectUsluga = document.querySelector('#usluga');
const inputIlosc = document.querySelector('#ilosc');
const checkRegulamin = document.querySelector('#regulamin');
const btnZamow = document.querySelector('#btn-zamow');
const btnReset = document.querySelector('#btn-reset');
const komunikatStatus = document.querySelector('#komunikat-status');
const podsumowanie = document.querySelector('#podsumowanie');

function ustawStan(pole, poprawne) {
  if (poprawne) {
    pole.classList.remove('blad-walidacji');
    pole.classList.add('sukces-walidacji');
  } else {
    pole.classList.add('blad-walidacji');
    pole.classList.remove('sukces-walidacji');
  }
}

btnMenu.addEventListener('click', () => {
  menuBoczne.classList.toggle('otwarty');
});

btnMotyw.addEventListener('click', () => {
  document.body.classList.toggle('ciemny-motyw');
});

btnZamow.addEventListener('click', () => {
  const imieOk = inputImie.value.trim().length >= 3;
  const emailOk = inputEmail.value.includes('@');
  const iloscOk = Number(inputIlosc.value) >= 1;
  const regulaminOk = checkRegulamin.checked;

  ustawStan(inputImie, imieOk);
  ustawStan(inputEmail, emailOk);
  ustawStan(inputIlosc, iloscOk);

  if (!regulaminOk) {
    komunikatStatus.textContent = 'Wymagana akceptacja regulaminu!';
  } else {
    komunikatStatus.textContent = '';
  }

  if (imieOk && emailOk && iloscOk && regulaminOk) {
    const koszt = Number(selectUsluga.value) * Number(inputIlosc.value);
    podsumowanie.textContent = `Wycena gotowa. Łączny koszt zamówienia brutto: ${koszt} zł`;
    podsumowanie.classList.remove('ukryty');
  } else {
    podsumowanie.classList.add('ukryty');
  }
});

btnReset.addEventListener('click', () => {
  inputImie.value = '';
  inputEmail.value = '';
  selectUsluga.selectedIndex = 0;
  inputIlosc.value = 1;
  checkRegulamin.checked = false;

  inputImie.classList.remove('blad-walidacji', 'sukces-walidacji');
  inputEmail.classList.remove('blad-walidacji', 'sukces-walidacji');
  inputIlosc.classList.remove('blad-walidacji', 'sukces-walidacji');

  podsumowanie.textContent = '';
  podsumowanie.classList.add('ukryty');
  komunikatStatus.textContent = '';
});
