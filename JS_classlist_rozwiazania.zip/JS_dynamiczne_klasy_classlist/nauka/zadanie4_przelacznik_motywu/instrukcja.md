# Zadanie 4: Przełącznik motywu strony (Dark / Light Mode)

## Cel
Celem zadania jest utworzenie przełącznika motywu wizualnego na stronie kawiarni speciality, który za pomocą `classList.toggle()` dodaje lub usuwa klasę `.jasny-motyw` z głównego elementu `<body>`. Sukces zadania poznasz po tym, że kliknięcie przycisku płynnie przełącza paletę barw całego serwisu między motywem ciemnym a jasnym oraz aktualizuje etykietę przycisku i wskaźnik trybu.

W praktyce programistycznej sterowanie klasą na elemencie nadrzędnym (`<body>` lub `<html>`) wykorzystywane jest do:
- Przełączania trybu wysokiego kontrastu (a11y) w serwisach urzędowych i edukacyjnych.
- Zmiany motywu graficznego platformy (np. wersja świąteczna, letnia, biznesowa).
- Włączania trybu skupienia (focus mode) w edytorach tekstu i czytnikach artykułów.

## Wskazówki aktywizujące
1. Przypomnij sobie z sekcji 2 i 5 pliku `teoria.md`, jak odwołać się do elementu `body` (możesz użyć `document.body` lub `document.querySelector('body')`).
2. Zastanów się: jak kaskada CSS pozwala zmienić kolory wszystkich elementów potomnych za pomocą jednej klasy dodanej do `body` (np. `body.jasny-motyw .karta`)?
3. W konsoli przeglądarki (`F12`) przetestuj wywołanie:
   `document.body.classList.toggle('jasny-motyw')`

## Treść do wpisania
Wpisz dokładnie na stronie: „Aroma Cafe — Kawiarnia Rzemieślnicza” oraz „Świeżo palone ziarna z Etiopii, Kolumbii i Gwatemali” wraz z etykietami przycisków „Przełącz na jasny motyw” oraz „Przełącz na ciemny motyw”.

## Wymagania
1. W pliku `index.html` zdefiniuj:
   - Nagłówek kawiarni z tytułem i podtytułem.
   - Przycisk o identyfikatorze `#btn-motyw` z tekstem „Przełącz na jasny motyw”.
   - Paragraf informacyjny o identyfikatorze `#status-motywu` z tekstem początkowym „Aktualny motyw: Nocny (ciemny)”.
   - Kartę produktu z opisem specjału dnia.
2. W pliku `style.css` zdefiniuj domyślny ciemny motyw oraz reguły dla klasy `.jasny-motyw`:
   - `body.jasny-motyw` zmienia tło strony na jasne `#f1f5f9` oraz kolor tekstu na `#0f172a`.
   - `body.jasny-motyw .karta` zmienia tło karty na białe `#ffffff` i dodaje subtelny cień.
3. W pliku `script.js`:
   - Pobierz przycisk `#btn-motyw` oraz paragraf `#status-motywu`.
   - Podepnij zdarzenie `click` pod przycisk: wywołaj `document.body.classList.toggle('jasny-motyw')`.
   - Sprawdź stan za pomocą `document.body.classList.contains('jasny-motyw')`.
   - Jeśli motyw jasny jest aktywny: ustaw tekst przycisku na „Przełącz na ciemny motyw”, a tekst statusu na „Aktualny motyw: Dzienny (jasny)”.
   - Jeśli motyw jasny jest wyłączony: przywróć tekst przycisku „Przełącz na jasny motyw” oraz status „Aktualny motyw: Nocny (ciemny)”.

## Przykład
- **Stan początkowy:** Strona renderuje się w domyślnym ciemnym motywie (`#0b0f19`), przycisk głosi: „Przełącz na jasny motyw”, a status: „Aktualny motyw: Nocny (ciemny)”.
- **Akcja 1:** Użytkownik klika przycisk przełącznika motywu.
- **Efekt 1:** Tło całego dokumentu staje się jasne (`#f1f5f9`), karta kawiarni przybiera kolor biały, przycisk zmienia treść na: „Przełącz na ciemny motyw”, a status wskazuje: „Aktualny motyw: Dzienny (jasny)”.
- **Akcja 2:** Ponowne kliknięcie przycisku przywraca ciemną paletę barw i pierwotne teksty.
