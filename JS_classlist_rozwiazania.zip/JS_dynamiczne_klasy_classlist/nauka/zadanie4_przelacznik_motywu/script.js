const btnMotyw = document.querySelector('#btn-motyw');
const statusMotywu = document.querySelector('#status-motywu');

btnMotyw.addEventListener('click', () => {
  document.body.classList.toggle('jasny-motyw');

  if (document.body.classList.contains('jasny-motyw')) {
    btnMotyw.textContent = 'Przełącz na ciemny motyw';
    statusMotywu.textContent = 'Aktualny motyw: Dzienny (jasny)';
  } else {
    btnMotyw.textContent = 'Przełącz na jasny motyw';
    statusMotywu.textContent = 'Aktualny motyw: Nocny (ciemny)';
  }
});
