# Zadanie 2: Przełącznik widoczności elementów (`classList.toggle`)

## Cel
Celem zadania jest utworzenie interfejsu karty serwisowej w warsztacie samochodowym z pojedynczym przyciskiem przełączającym widoczność szczegółowego harmonogramu naprawy. Sukces zadania poznasz po tym, że każde kolejne kliknięcie przycisku na przemian odsłania i ukrywa panel techniczny z listą wymienianych części, aktualizując etykietę na przycisku.

W praktyce programistycznej ta sama technika przełączania klasy widoczności (`.ukryty`) za pomocą `classList.toggle()` wykorzystywana jest do:
- Otwierania i zwijania bocznego paska nawigacyjnego (sidebar) na urządzeniach mobilnych.
- Wyświetlania okna podglądu koszyka w sklepie internetowym po najechaniu lub kliknięciu ikony koszyka.
- Ukrywania i pokazywania podpowiedzi kontekstowych (tooltip) przy skomplikowanych polach konfiguratora.

## Wskazówki aktywizujące
1. Przeczytaj sekcję 5 pliku `teoria.md` omawiającą metodę `classList.toggle()`. Zwróć uwagę, co zwraca ta metoda, gdy dodaje klasę, a co, gdy ją usuwa.
2. Zastanów się: w jaki sposób wartość zwracana przez `toggle()` ułatwia zmianę tekstu na przycisku (np. z „Pokaż szczegóły” na „Ukryj szczegóły”)?
3. W konsoli przeglądarki (`F12`) przetestuj wywołanie:
   `document.querySelector('#szczegoly-naprawy').classList.toggle('ukryty')`

## Treść do wpisania
Wpisz dokładnie na stronie: „AutoSerwis Precyzja — Status Naprawy Pojazdu” oraz zlecenie „Zlecenie naprawy #2026/AS/401 — Audi A4 2.0 TDI” wraz z etykietami przycisków „Pokaż szczegóły techniczne” i „Ukryj szczegóły techniczne”.

## Wymagania
1. W pliku `index.html` zdefiniuj:
   - Nagłówek zlecenia oraz podstawową informację o statusie.
   - Przycisk o identyfikatorze `#btn-szczegoly` z tekstem „Pokaż szczegóły techniczne”.
   - Blok panelu technicznego o identyfikatorze `#szczegoly-naprawy`, który początkowo posiada klasę `.ukryty`.
2. W pliku `style.css` zdefiniuj regułę:
   ```css
   .ukryty {
     display: none !important;
   }
   ```
3. W pliku `script.js`:
   - Pobierz przycisk `#btn-szczegoly` oraz kontener `#szczegoly-naprawy`.
   - Zarejestruj zdarzenie `click` na przycisku `#btn-szczegoly`.
   - Wewnątrz procedury obsługi przełącz klasę `ukryty` na kontenerze za pomocą `szczegoly.classList.toggle('ukryty')`.
   - Sprawdź, czy klasa jest obecnie na elemencie (`contains('ukryty')` lub wynik `toggle`), i jeśli kontener jest ukryty — ustaw tekst przycisku na „Pokaż szczegóły techniczne”, a jeśli jest widoczny — ustaw na „Ukryj szczegóły techniczne”.

## Przykład
- **Stan początkowy:** Widoczna jest karta zlecenia Audi A4. Lista podzespołów jest niewidoczna, a przycisk ma napis: „Pokaż szczegóły techniczne”.
- **Akcja 1:** Użytkownik klika przycisk „Pokaż szczegóły techniczne”.
- **Efekt 1:** Klasa `.ukryty` zostaje usunięta, lista czterech podzespołów pojawia się pod statusem, a tekst na przycisku zmienia się na: „Ukryj szczegóły techniczne”.
- **Akcja 2:** Użytkownik ponownie klika ten sam przycisk.
- **Efekt 2:** Klasa `.ukryty` powraca na kontener, szczegóły znikają, a tekst na przycisku wraca do: „Pokaż szczegóły techniczne”.
