const btnSzczegoly = document.querySelector('#btn-szczegoly');
const panelSzczegoly = document.querySelector('#szczegoly-naprawy');

btnSzczegoly.addEventListener('click', () => {
  panelSzczegoly.classList.toggle('ukryty');

  if (panelSzczegoly.classList.contains('ukryty')) {
    btnSzczegoly.textContent = 'Pokaż szczegóły techniczne';
  } else {
    btnSzczegoly.textContent = 'Ukryj szczegóły techniczne';
  }
});
