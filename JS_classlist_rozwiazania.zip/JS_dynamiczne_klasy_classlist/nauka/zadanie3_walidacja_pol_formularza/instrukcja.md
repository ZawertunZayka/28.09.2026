# Zadanie 3: Wizualna walidacja pól formularza

## Cel
Celem zadania jest oprogramowanie natychmiastowej walidacji formularza rejestracji do biuletynu ogrodniczego z użyciem klas `.blad-walidacji` oraz `.sukces-walidacji`. Sukces zadania poznasz po tym, że podczas wpisywania imienia oraz adresu e-mail ramki pól natychmiast reagują na poprawność danych (czerwona obwódka przy błędzie, zielona przy sukcesie), a komunikat tekstowy wyjaśnia przyczynę błędu.

W praktyce programistycznej dynamiczne klasy walidacyjne wykorzystywane są do:
- Wizualnego potwierdzenia poprawności numeru telefonu podczas składania zamówienia kurierskiego.
- Podświetlania na czerwono zbyt krótkiego hasła podczas zakładania konta bankowego.
- Oznaczania kodu pocztowego zieloną ramką w kreatorze adresu dostawy w sklepie odzieżowym.

## Wskazówki aktywizujące
1. Zobacz w sekcji 3 i 4 pliku `teoria.md`, jak stosować `classList.add()` i `classList.remove()` lub jak w sekcji 5 wykorzystać dwuargumentowy `classList.toggle('blad-walidacji', warunek)`.
2. Zastanów się: dlaczego przed dodaniem klasy `.sukces-walidacji` warto usunąć klasę `.blad-walidacji` (lub odwrotnie)?
3. W konsoli przeglądarki (`F12`) możesz sprawdzić:
   `document.querySelector('#imie').classList.contains('blad-walidacji')`

## Treść do wpisania
Wpisz dokładnie na stronie: „Zielony Ogród — Zapis na Poradnik Sezonowy” oraz etykiety „Imię ogrodnika (minimum 3 znaki):”, „Adres e-mail (musi zawierać znak @):” oraz komunikat „Formularz poprawny. Dziękujemy za dołączenie do klubu Zielony Ogród!”.

## Wymagania
1. W pliku `index.html` zdefiniuj:
   - Formularz z polami `#imie`, `#email` i przyciskiem `#btn-zapisz` typu `button`.
   - Elementy na komunikaty o identyfikatorach `#komunikat-imie`, `#komunikat-email` oraz `#podsumowanie`.
2. W pliku `style.css` zdefiniuj klasy:
   - `.blad-walidacji` (czerwona ramka `border: 2px solid #ef4444`, jasnoczerwone tło).
   - `.sukces-walidacji` (zielona ramka `border: 2px solid #22c55e`, jasnozielone tło).
3. W pliku `script.js`:
   - Dodaj nasłuchiwanie zdarzenia `input` na polu `#imie`: jeśli długość tekstu jest mniejsza niż 3 znaki, dodaj klasę `.blad-walidacji`, usuń `.sukces-walidacji` i wyświetl komunikat błędu imienia; w przeciwnym razie usuń `.blad-walidacji`, dodaj `.sukces-walidacji` i wyczyść komunikat.
   - Dodaj nasłuchiwanie zdarzenia `input` na polu `#email`: jeśli tekst nie zawiera znaku `@` (użyj `email.value.includes('@')`), dodaj `.blad-walidacji`, usuń `.sukces-walidacji` i wyświetl komunikat błędu e-mail; w przeciwnym razie dodaj `.sukces-walidacji`, usuń `.blad-walidacji` i wyczyść komunikat.
   - Po kliknięciu przycisku `#btn-zapisz` sprawdź, czy oba pola posiadają klasę `.sukces-walidacji`. Jeśli tak — wyświetl w `#podsumowanie` tekst sukcesu; jeśli nie — wyświetl „Błąd: Popraw zaznaczone pola przed wysłaniem!”.

## Przykład
- **Stan początkowy:** Pola formularza są puste, posiadają standardowe ciemne obramowanie, a komunikaty są niewidoczne.
- **Akcja 1:** Użytkownik wpisuje w polu imienia literę „A”.
- **Efekt 1:** Pole natychmiast otrzymuje klasę `.blad-walidacji` (czerwona ramka) i pod polem pojawia się tekst: „Błąd: Imię musi zawierać co najmniej 3 znaki!”.
- **Akcja 2:** Użytkownik dopisuje kolejne litery, tworząc „Anna”, oraz wpisuje e-mail „anna@ogrod.pl”.
- **Efekt 2:** Oba pola zmieniają styl na `.sukces-walidacji` (zielone ramki), błędy znikają, a kliknięcie przycisku wyświetla komunikat: „Formularz poprawny. Dziękujemy za dołączenie do klubu Zielony Ogród!”.
