const inputImie = document.querySelector('#imie');
const inputEmail = document.querySelector('#email');
const komImie = document.querySelector('#komunikat-imie');
const komEmail = document.querySelector('#komunikat-email');
const btnZapisz = document.querySelector('#btn-zapisz');
const podsumowanie = document.querySelector('#podsumowanie');

inputImie.addEventListener('input', () => {
  if (inputImie.value.length < 3) {
    inputImie.classList.add('blad-walidacji');
    inputImie.classList.remove('sukces-walidacji');
    komImie.textContent = 'Błąd: Imię musi zawierać co najmniej 3 znaki!';
  } else {
    inputImie.classList.remove('blad-walidacji');
    inputImie.classList.add('sukces-walidacji');
    komImie.textContent = '';
  }
});

inputEmail.addEventListener('input', () => {
  if (!inputEmail.value.includes('@')) {
    inputEmail.classList.add('blad-walidacji');
    inputEmail.classList.remove('sukces-walidacji');
    komEmail.textContent = 'Błąd: Wprowadź poprawny adres e-mail ze znakiem @!';
  } else {
    inputEmail.classList.remove('blad-walidacji');
    inputEmail.classList.add('sukces-walidacji');
    komEmail.textContent = '';
  }
});

btnZapisz.addEventListener('click', () => {
  if (inputImie.classList.contains('sukces-walidacji') && inputEmail.classList.contains('sukces-walidacji')) {
    podsumowanie.textContent = 'Formularz poprawny. Dziękujemy za dołączenie do klubu Zielony Ogród!';
  } else {
    podsumowanie.textContent = 'Błąd: Popraw zaznaczone pola przed wysłaniem!';
  }
});
