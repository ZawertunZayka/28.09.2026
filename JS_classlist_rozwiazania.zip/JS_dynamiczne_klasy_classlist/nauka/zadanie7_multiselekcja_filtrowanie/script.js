const kartyProduktow = document.querySelectorAll('.karta-produktu');
const przyciskiFiltrow = document.querySelectorAll('.btn-filtr');
const btnOdznacz = document.querySelector('#btn-odznacz');
const podsumowanie = document.querySelector('#podsumowanie');

function aktualizujLicznik() {
  const ileZaznaczonych = document.querySelectorAll('.karta-produktu.zaznaczony').length;
  podsumowanie.textContent = `Liczba zaznaczonych produktów: ${ileZaznaczonych} szt.`;
}

kartyProduktow.forEach((karta) => {
  karta.addEventListener('click', () => {
    karta.classList.toggle('zaznaczony');
    aktualizujLicznik();
  });
});

przyciskiFiltrow.forEach((btn) => {
  btn.addEventListener('click', () => {
    przyciskiFiltrow.forEach((p) => {
      p.classList.remove('aktywny');
    });
    btn.classList.add('aktywny');

    const kat = btn.dataset.kategoria;

    kartyProduktow.forEach((karta) => {
      if (kat === 'wszystkie' || karta.dataset.kategoria === kat) {
        karta.classList.remove('ukryty');
      } else {
        karta.classList.add('ukryty');
      }
    });
  });
});

btnOdznacz.addEventListener('click', () => {
  kartyProduktow.forEach((karta) => {
    karta.classList.remove('zaznaczony');
  });
  aktualizujLicznik();
});
