# Zadanie 7: Dynamiczny panel filtrowania i multiselekcji

## Cel
Celem zadania jest utworzenie interfejsu katalogu produktów w hurtowni materiałów biurowych z kafelkami ofertowymi, w którym użytkownik może wielokrotnie zaznaczać i odznaczać produkty za pomocą klasy `.zaznaczony` oraz filtrować widok przyciskami kategorii za pomocą klasy `.ukryty`. Sukces zadania poznasz po tym, że klikanie produktów sumuje zaznaczone pozycje na żywo, a kliknięcie filtru kategorii ukrywa niepasujące towary bez utraty ich stanu.

W praktyce programistycznej połączenie multiselekcji i filtrowania klasami CSS wykorzystywane jest do:
- Masowego zaznaczania wiadomości e-mail do usunięcia lub archiwizacji w kliencie pocztowym.
- Wyboru kilku dodatków do pizzy w interaktywnym menu restauracji.
- Filtrowania kandydatów według działu w panelu rekrutacyjnym HR.

## Wskazówki aktywizujące
1. Przypomnij sobie z sekcji 5 i 8 pliku `teoria.md`, jak łączyć `classList.toggle()` z iteracją po elementach kolekcji `NodeList`.
2. Zastanów się: jak za pomocą metody `document.querySelectorAll('.karta-produktu.zaznaczony').length` natychmiast policzyć liczbę zaznaczonych towarów?
3. W konsoli przeglądarki (`F12`) przetestuj:
   `document.querySelectorAll('.karta-produktu.zaznaczony').length`

## Treść do wpisania
Wpisz dokładnie na stronie: „PapierBiur — Hurtownia Artykułów Papierniczych” oraz filtry „Wszystkie artykuły”, „Papiery i bloki”, „Archiwizacja” i produkty „Papier ksero A4 80g PolSpeed (karton 5 ryz)”.

## Wymagania
1. W pliku `index.html` zdefiniuj:
   - Panel filtrów z przyciskami `.btn-filtr` o atrybutach `data-kategoria="wszystkie"`, `data-kategoria="papier"`, `data-kategoria="archiwum"`.
   - Siatkę 4 kart produktów `.karta-produktu` z atrybutami `data-kategoria` odpowiadającymi rodzajowi towaru.
   - Pasek podsumowania o identyfikatorze `#podsumowanie` z tekstem „Liczba zaznaczonych produktów: 0 szt.”.
   - Przycisk o identyfikatorze `#btn-odznacz` z tekstem „Odznacz wszystkie”.
2. W pliku `style.css`:
   - `.karta-produktu.zaznaczony` otrzymuje wyróżnioną szmaragdową ramkę (`border: 2px solid #10b981`), tło `#064e3b` oraz wskaźnik zaznaczenia.
   - `.ukryty` ukrywa karty (`display: none !important;`).
3. W pliku `script.js`:
   - Dodaj obsługę kliknięcia na każdej karcie produktu: przełącz klasę `zaznaczony` i zaktualizuj licznik w `#podsumowanie`.
   - Dodaj obsługę kliknięcia na przyciskach filtrów: usuń klasę `aktywny` ze wszystkich przycisków, nadaj ją klikniętemu, a na kartach produktów steruj klasą `ukryty` w zależności od tego, czy kategoria karty pasuje do wybranego filtra (`wszystkie` odsłania każdą kartę).
   - Dodaj obsługę przycisku `#btn-odznacz`: usuń klasę `zaznaczony` ze wszystkich kart i zaktualizuj licznik na 0 szt.

## Przykład
- **Stan początkowy:** Wyświetlone są 4 produkty z szarym obramowaniem. Licznik wskazuje: „Liczba zaznaczonych produktów: 0 szt.”.
- **Akcja 1:** Użytkownik klika na produkt 1 i produkt 3.
- **Efekt 1:** Obie karty przyjmują zielony styl `.zaznaczony`, a licznik aktualizuje się na: „Liczba zaznaczonych produktów: 2 szt.”.
- **Akcja 2:** Użytkownik klika filtr „Archiwizacja”.
- **Efekt 2:** Karty z kategorii papier otrzymują klasę `.ukryty`, a na ekranie pozostają wyłącznie Segregator oraz Pudło Esselte.
