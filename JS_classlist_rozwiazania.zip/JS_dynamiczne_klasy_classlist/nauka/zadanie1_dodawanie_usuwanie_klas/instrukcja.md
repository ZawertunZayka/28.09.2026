# Zadanie 1: Proste dodawanie i usuwanie klas CSS

## Cel
Celem zadania jest utworzenie interfejsu panelu rabatowego w księgarni internetowej, w którym kliknięcie przycisku aktywacji dodaje klasę wyróżnienia do banera promocyjnego, a przycisk dezaktywacji ją usuwa. Sukces zadania poznasz po tym, że kliknięcie przycisku aktywacji nadaje ramce styl promocyjny bez przeładowania strony, a kliknięcie dezaktywacji przywraca stan pierwotny.

W praktyce programistycznej ta sama technika dodawania i usuwania pojedynczych klas CSS wykorzystywana jest do:
- Podświetlania aktywnego wiersza w tabeli magazynowej po wybraniu towaru.
- Zmiany stanu przycisku „Dodaj do obserwowanych” w portalu ogłoszeniowym.
- Oznaczania karty kursu online jako ukończonej w panelu edukacyjnym.

## Wskazówki aktywizujące
1. Przypomnij sobie z sekcji 3 i 4 pliku `teoria.md`, jak działają metody `classList.add()` oraz `classList.remove()`.
2. Zastanów się: dlaczego do metody `classList.add()` przekazujesz samą nazwę klasy w cudzysłowie, bez kropki na początku?
3. W konsoli przeglądarki (`F12`) możesz sprawdzić działanie obiektu, wpisując:
   `document.querySelector('#baner-promocji').classList`

## Treść do wpisania
Wpisz dokładnie: „Księgarnia Czytelnik — Panel Promocji” oraz „Książka tygodnia: Czysty kod w JavaScript — rabat 30% z kodem CZYTAM30!” oraz przyciski „Aktywuj wyróżnienie” i „Wyłącz wyróżnienie”.

## Wymagania
1. W pliku `index.html` zdefiniuj:
   - Kontener banera o identyfikatorze `#baner-promocji`.
   - Przycisk o identyfikatorze `#btn-aktywuj` z tekstem „Aktywuj wyróżnienie”.
   - Przycisk o identyfikatorze `#btn-dezaktywuj` z tekstem „Wyłącz wyróżnienie”.
   - Paragraf komunikatu o identyfikatorze `#komunikat-status`.
2. W pliku `style.css` przygotuj klasę `.aktywny`, która nadaje banerowi wyrazistą ramkę, jasne tło oraz pogrubiony tekst.
3. W pliku `script.js`:
   - Pobierz elementy za pomocą `document.querySelector()`.
   - Podepnij zdarzenie `click` pod przycisk `#btn-aktywuj`, które wywołuje `classList.add('aktywny')` na banerze oraz wpisuje do `#komunikat-status` tekst „Wyróżnienie promocyjne zostało włączone.”.
   - Podepnij zdarzenie `click` pod przycisk `#btn-dezaktywuj`, które wywołuje `classList.remove('aktywny')` na banerze oraz wpisuje do `#komunikat-status` tekst „Wyróżnienie promocyjne zostało wyłączone.”.

## Przykład
- **Stan początkowy:** Na ciemnym tle wyświetla się standardowa ramka banera z książką tygodnia. Komunikat statusu jest pusty.
- **Akcja 1:** Użytkownik klika przycisk „Aktywuj wyróżnienie”.
- **Efekt 1:** Baner natychmiast zmienia obramowanie i tło dzięki klasie `.aktywny`, a pod spodem pojawia się napis: „Wyróżnienie promocyjne zostało włączone.”.
- **Akcja 2:** Użytkownik klika przycisk „Wyłącz wyróżnienie”.
- **Efekt 2:** Klasa `.aktywny` zostaje usunięta, baner wraca do szarej ramki, a komunikat głosi: „Wyróżnienie promocyjne zostało wyłączone.”.
