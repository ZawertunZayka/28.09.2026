const przyciski = document.querySelectorAll('.tab-btn');
const panele = document.querySelectorAll('.tab-panel');

przyciski.forEach((btn) => {
  btn.addEventListener('click', () => {
    przyciski.forEach((p) => {
      p.classList.remove('aktywny');
    });

    panele.forEach((panel) => {
      panel.classList.add('ukryty');
    });

    btn.classList.add('aktywny');

    const cel = btn.dataset.cel;
    document.querySelector('#' + cel).classList.remove('ukryty');
  });
});
