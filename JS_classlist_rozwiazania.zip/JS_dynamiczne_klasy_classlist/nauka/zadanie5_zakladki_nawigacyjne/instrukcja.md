# Zadanie 5: Nawigacja zakładkowa (Tabs)

## Cel
Celem zadania jest utworzenie komponentu zakładek informacyjnych dla wypożyczalni sprzętu turystycznego z użyciem `querySelectorAll`, pętli `forEach` oraz klas `.aktywny` i `.ukryty`. Sukces zadania poznasz po tym, że kliknięcie dowolnej zakładki aktywuje odpowiedni przycisk, ukrywa dotychczas wyświetlany opis i odsłania dedykowany panel z ofertą sprzętu.

W praktyce programistycznej obsługa zakładek za pomocą klas CSS wykorzystywana jest do:
- Przełączania widoków specyfikacji technicznej, opinii i dostawy w karcie produktu w sklepie internetowym.
- Wyboru metody płatności (karta, szybki przelew, BLIK) w koszyku zamówień.
- Nawigacji między sekcjami ustawień konta użytkownika w panelu klienta.

## Wskazówki aktywizujące
1. Przeczytaj sekcję 8 pliku `teoria.md` omawiającą iterację po kolekcji `NodeList` za pomocą `forEach`.
2. Zastanów się: dlaczego przed nadaniem klasy `.aktywny` nowemu przyciskowi i odsłonięciem jego treści należy najpierw usunąć klasę aktywności ze wszystkich przycisków i ukryć wszystkie panele?
3. W konsoli przeglądarki (`F12`) przetestuj:
   `document.querySelectorAll('.tab-btn').forEach(btn => console.log(btn.dataset.cel))`

## Treść do wpisania
Wpisz dokładnie na stronie: „TrekRent — Wypożyczalnia Sprzętu Górskiego” oraz etykiety zakładek „Namioty wyprawowe”, „Plecaki trekkingowe” i „Sprzęt wspinaczkowy” z opisem „Namioty 2- i 4-osobowe marek Marbut i Fjord Nansen”.

## Wymagania
1. W pliku `index.html` zdefiniuj:
   - Trzy przyciski zakładek o wspólnej klasie `.tab-btn` oraz atrybutach `data-cel="panel-namioty"`, `data-cel="panel-plecaki"`, `data-cel="panel-wspinaczka"`. Pierwszy przycisk ma dodatkowo klasę `.aktywny`.
   - Trzy kontenery treści o wspólnej klasie `.tab-panel` oraz identyfikatorach `#panel-namioty`, `#panel-plecaki`, `#panel-wspinaczka`. Pierwszy panel jest widoczny, a dwa pozostałe posiadają klasę `.ukryty`.
2. W pliku `style.css`:
   - `.tab-btn.aktywny` ma wyróżniony kolor tła (`#0284c7`), biały tekst i pogrubienie.
   - `.ukryty` ukrywa panel (`display: none !important;`).
3. W pliku `script.js`:
   - Pobierz wszystkie przyciski zakładek (`.tab-btn`) oraz wszystkie panele (`.tab-panel`).
   - Za pomocą pętli `forEach` zarejestruj nasłuchiwanie zdarzenia `click` na każdym przycisku zakładki.
   - Po kliknięciu:
     1. Przeiteruj po wszystkich przyciskach i usuń klasę `.aktywny`.
     2. Przeiteruj po wszystkich panelach i dodaj klasę `.ukryty`.
     3. Dodaj klasę `.aktywny` do klikniętego przycisku.
     4. Odczytaj cel z atrybutu `dataset.cel` i usuń klasę `.ukryty` z odpowiedniego panelu (`document.querySelector('#' + cel)`).

## Przykład
- **Stan początkowy:** Podświetlona jest zakładka „Namioty wyprawowe”, a pod spodem wyświetla się opis stelaży duraluminiowych i wodoodporności. Pozostałe opisy są ukryte.
- **Akcja 1:** Użytkownik klika zakładkę „Plecaki trekkingowe”.
- **Efekt 1:** Zakładka namiotów traci wyróżnienie, zakładka plecaków otrzymuje klasę `.aktywny`, a panel namiotów zostaje zastąpiony opisem plecaków z systemem Vari-Quick.
- **Akcja 2:** Użytkownik klika zakładkę „Sprzęt wspinaczkowy”.
- **Efekt 2:** Aktywna staje się trzecia zakładka, a na ekranie pojawia się lista czeków i raków Black Diamond.
