// 1. Pobierz input range i paragraf
// 2. addEventListener 'input'
// 3. style.fontSize = value + 'px'
