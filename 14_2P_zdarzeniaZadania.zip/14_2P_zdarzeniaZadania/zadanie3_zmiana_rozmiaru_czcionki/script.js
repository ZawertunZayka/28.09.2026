// 1. Pobierz input range i paragraf
// 2. addEventListener 'input'
// 3. style.fontSize = value + 'px'

const suwak = document.getElementById('sizeRange');
const tekst = document.getElementById('textContent');

suwak.addEventListener('input', function () {
  tekst.style.fontSize = suwak.value + 'px';
});
