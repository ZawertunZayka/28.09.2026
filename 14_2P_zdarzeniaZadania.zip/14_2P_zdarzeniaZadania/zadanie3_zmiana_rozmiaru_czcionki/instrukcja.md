# Sprawdzian B – Zadanie 3: Rozmiar czcionki

## Cel

Suwak `#sizeRange` na żywo zmienia `font-size` akapitu `#textContent`. Zakres (`min` / `max`) jest już w HTML.

## Przydatne

Suwak przy przeciąganiu zmienia wartość wiele razy. Które zdarzenie aktualizuje tekst od razu, a które dopiero po puszczeniu? Wartość suwaka to `.value` (tekst). Do `font-size` potrzebujesz jednostki, na przykład dopisania `"px"`.

## Wymagania

1. Przesuwanie suwaka od razu zmienia wielkość liter.
2. Korzystasz z zakresu zapisanego w HTML, nie wymyślasz własnych granic.
3. W stopce zostawiasz „Imię Nazwisko klasa”.

## Przykład

Przeciągnij suwak w prawo. Litery w akapicie stają się wyraźnie większe. Przeciągnij w lewo. Tekst maleje.
