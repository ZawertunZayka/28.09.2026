// 1. Pobierz przyciski i treści
// 2. addEventListener click na przyciski
// 3. W funkcji:
//    - ukryj wszystkie tresci (dodaj klase .hidden)
//    - pobierz data-target kliknietego
//    - pokaz odpowiednia tresc (usun klase .hidden)

const przyciski = document.querySelectorAll('.tab-btn');
const tresci = document.querySelectorAll('.content');

przyciski.forEach(function (przycisk) {
  przycisk.addEventListener('click', function () {
    tresci.forEach(function (tresc) {
      tresc.classList.add('hidden');
    });
    const cel = przycisk.getAttribute('data-target');
    document.getElementById(cel).classList.remove('hidden');
  });
});
