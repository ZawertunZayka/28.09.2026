// 1. Pobierz przyciski i treści
// 2. addEventListener click na przyciski
// 3. W funkcji:
//    - ukryj wszystkie tresci (dodaj klase .hidden)
//    - pobierz data-target kliknietego
//    - pokaz odpowiednia tresc (usun klase .hidden)
