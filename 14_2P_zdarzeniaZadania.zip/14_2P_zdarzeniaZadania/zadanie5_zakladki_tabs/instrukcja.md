# Sprawdzian B – Zadanie 5: Zakładki

## Cel

Klik przycisku `.tab-btn` pokazuje pasujący panel (`data-target` wskazuje `id`: `#desc1`, `#desc2` albo `#desc3`) i ukrywa pozostałe. Klasa `.hidden` jest już w CSS.

## Przydatne

Przycisków jest kilka, więc każdy potrzebuje nasłuchu. Skąd wziąć `id` panelu — z tekstu przycisku czy z atrybutu? Najpierw schowaj wszystkie panele `.content`, potem pokaż jeden. Możesz dodać albo zdjąć klasę `hidden`, albo zmienić `style.display`. `classList` dokładniej poznasz w dziale 15.

## Wymagania

1. W danym momencie widać tylko jedną treść.
2. Wszystkie trzy przyciski działają: „O nas”, „Oferta”, „Kontakt”.
3. W stopce zostawiasz „Imię Nazwisko klasa”.

## Przykład

Kliknij „Oferta”. Widać tekst oferty, a „O nas” i „Kontakt” są schowane. Kliknij „Kontakt”. Zostaje tylko treść kontaktu.
