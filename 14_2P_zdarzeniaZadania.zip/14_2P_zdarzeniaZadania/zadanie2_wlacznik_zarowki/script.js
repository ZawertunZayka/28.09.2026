// 1. Zmienna stan = false
// 2. addEventListener click
// 3. IF stan... zmien src na ON
// 4. ELSE... zmien src na OFF

const zarowka = document.getElementById('bulb');
const OFF = 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/icons/lightbulb-off.svg';
const ON = 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/icons/lightbulb-fill.svg';
let stan = false;

zarowka.addEventListener('click', function () {
  stan = !stan;
  if (stan) {
    zarowka.src = ON;
    zarowka.alt = 'Żarówka włączona';
  } else {
    zarowka.src = OFF;
    zarowka.alt = 'Żarówka wyłączona';
  }
});
