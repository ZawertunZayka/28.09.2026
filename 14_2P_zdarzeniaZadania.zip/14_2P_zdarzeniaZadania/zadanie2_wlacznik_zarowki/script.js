// 1. Zmienna stan = false
// 2. addEventListener click
// 3. IF stan... zmien src na ON
// 4. ELSE... zmien src na OFF
