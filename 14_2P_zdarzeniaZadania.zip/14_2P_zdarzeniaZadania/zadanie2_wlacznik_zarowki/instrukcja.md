# Sprawdzian B – Zadanie 2: Żarówka

## Cel

Klik w obrazek `#bulb` przełącza go między stanem włączonym a wyłączonym. Zmieniasz adres `src` tego samego elementu.

## Przydatne

Nasłuch ląduje na obrazku. Stan możesz trzymać w zmiennej albo porównać obecny `src`. Nowy adres wstawiasz do właściwości `.src`. Drugi klik ma wrócić do poprzedniego obrazka, nie zostawiać żarówki zawsze włączonej.
żarówka wyłączona: "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/icons/lightbulb-off.svg"
żarówka włączona: "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/icons/lightbulb-fill.svg"

## Wymagania

1. Klik zmienia stan żarówki.
2. Kolejny klik wraca do poprzedniego obrazka.
3. W stopce zostawiasz „Imię Nazwisko klasa”.

## Przykład

Na starcie żarówka jest wyłączona. Kliknij w nią. Widać włączoną. Kliknij drugi raz. Znowu jest wyłączona.
