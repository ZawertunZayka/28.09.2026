# Zadanie 1: Serwis rowerowy — Wycena przeglądu technicznego

## Cel
Aplikacja ma umożliwić personelowi serwisu rowerowego natychmiastowe obliczenie łącznego kosztu wykonania przeglądów podstawowych dla podanej liczby jednośladów po naciśnięciu przycisku kalkulacji.

## Wskazówki / pułapki
- Jak zapewnić, aby skrypt pobrał wartość z kontrolki liczbowej dopiero w momencie interakcji użytkownika z przyciskiem, a nie w chwili uruchomienia pliku?
- W jaki sposób zapobiec błędom arytmetycznym wynikającym z faktu, że dane z pól formularza są domyślnie reprezentowane jako napisy?
- Sprawdź sekcję 2 w pliku `sprawdzian/README.md`, aby upewnić się, że prawidłowo przekazujesz funkcję do metody `addEventListener()`.

## Treść merytoryczna
- Tytuł aplikacji: "Serwis Rowerowy Velo-Centrum — Przeglądy Okresowe"
- Etykieta kontrolki liczbowej: "Liczba rowerów do przeglądu podstawowego:"
- Przycisk kalkulacji: "Oblicz koszt serwisu"
- Tekst początkowy: "Wprowadź liczbę jednośladów i naciśnij przycisk."
- Koszt przeglądu jednego roweru: 80.00 PLN
- Szablon wyniku: "Łączny koszt przeglądu: [KOSZT] PLN (liczba jednośladów: [ILOSC])."
- Komunikat błędu: "Błąd: Podaj prawidłową liczbę rowerów (minimum 1)."

## Wymagania
1. W pliku `index.html` korzystaj z gotowych elementów: pola `#liczba-rowerow` (wartość domyślna `1`, minimum `1`), przycisku `#btn-oblicz` oraz kontenera `#wynik`.
2. W pliku `script.js` zarejestruj zdarzenie `'click'` na przycisku `#btn-oblicz` metodą `addEventListener()`.
3. Po naciśnięciu przycisku skrypt odczytuje liczbę z pola `#liczba-rowerow` (konwersja `parseInt()`).
4. Jeżeli podana wartość jest mniejsza od 1 lub nie jest prawidłową liczbą, w elemencie `#wynik` ma pojawić się podany komunikat błędu.
5. Jeżeli wartość jest poprawna, skrypt wylicza łączną kwotę (stawka 80.00 PLN × liczba rowerów), formatuje ją do 2 miejsc po przecinku i umieszcza w elemencie `#wynik` wskazany szablon wyniku.

## Przykład
- Stan początkowy: Pole `#liczba-rowerow` zawiera wartość `1`. Element `#wynik` wyświetla napis: „Wprowadź liczbę jednośladów i naciśnij przycisk.”.
- Akcja użytkownika: Użytkownik zmienia wartość pola na `3` i klika przycisk „Oblicz koszt serwisu”.
- Efekt końcowy: Element `#wynik` wyświetla tekst: „Łączny koszt przeglądu: 240.00 PLN (liczba jednośladów: 3).”.
