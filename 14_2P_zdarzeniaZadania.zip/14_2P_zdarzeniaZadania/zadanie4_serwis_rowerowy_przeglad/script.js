// Sprawdzian Praktyczny — Grupa A — Zadanie 1
// Serwis Rowerowy Velo-Centrum

// 1. Zdefiniuj stałą określającą stawkę za jeden przegląd rowerowy (80.00 PLN)
const KOSZT_PRZEGLADU = 80.00;

// 2. Pobierz referencje do elementów interfejsu (#liczba-rowerow, #btn-oblicz, #wynik)
const poleLiczba = document.getElementById('liczba-rowerow');
const przyciskOblicz = document.getElementById('btn-oblicz');
const wynik = document.getElementById('wynik');

// 3. Zarejestruj obsługę kliknięcia przycisku i zaktualizuj zawartość elementu wynikowego
przyciskOblicz.addEventListener('click', function () {
  const ilosc = parseInt(poleLiczba.value);
  if (isNaN(ilosc) || ilosc < 1) {
    wynik.textContent = 'Błąd: Podaj prawidłową liczbę rowerów (minimum 1).';
    return;
  }
  const koszt = KOSZT_PRZEGLADU * ilosc;
  wynik.textContent = 'Łączny koszt przeglądu: ' + koszt.toFixed(2) + ' PLN (liczba jednośladów: ' + ilosc + ').';
});
