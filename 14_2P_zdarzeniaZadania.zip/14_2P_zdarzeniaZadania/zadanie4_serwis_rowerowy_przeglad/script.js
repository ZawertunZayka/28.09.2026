// Sprawdzian Praktyczny — Grupa A — Zadanie 1
// Serwis Rowerowy Velo-Centrum

// 1. Zdefiniuj stałą określającą stawkę za jeden przegląd rowerowy (80.00 PLN)
const KOSZT_PRZEGLADU = 80.00;

// 2. Pobierz referencje do elementów interfejsu (#liczba-rowerow, #btn-oblicz, #wynik)
// Twoje rozwiazanie

// 3. Zarejestruj obsługę kliknięcia przycisku i zaktualizuj zawartość elementu wynikowego
// Twoje rozwiazanie
