# Sprawdzian B – Zadanie 1: Licznik w dół

## Cel

Przycisk `#clickBtn` zmniejsza liczbę w `#countDisplay`. Na starcie widać 10. Gdy licznik dojdzie do 0, pokazujesz „Koniec!” albo zmieniasz kolor tekstu na czerwony.

## Przydatne

Które zdarzenie pasuje do przycisku? Licznik trzymaj w zmiennej — sam HTML nie pamięta, ile razy kliknięto. Na stronę wypisujesz zwykły tekst. Zero ma być odróżnione wizualnie od zwykłych liczb.

## Wymagania

1. Na starcie w `#countDisplay` jest 10.
2. Każde kliknięcie „Odejmij” zmniejsza liczbę o 1.
3. Przy zerze widać komunikat albo czerwony tekst.
4. W stopce zostawiasz „Imię Nazwisko klasa”.

## Przykład

Kliknij „Odejmij” dziesięć razy. Liczba spada do 0, a w akapicie pojawia się „Koniec!” albo czerwone zero.
