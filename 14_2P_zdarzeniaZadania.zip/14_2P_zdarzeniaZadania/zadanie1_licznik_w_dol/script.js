// 1. Zmienna licznik = 10
// 2. addEventListener click
// 3. licznik--
// 4. IF licznik == 0...

let licznik = 10;
const wyswietlacz = document.getElementById('countDisplay');
const przycisk = document.getElementById('clickBtn');

przycisk.addEventListener('click', function () {
  if (licznik > 0) {
    licznik--;
  }
  if (licznik === 0) {
    wyswietlacz.textContent = 'Koniec!';
    wyswietlacz.style.color = 'red';
  } else {
    wyswietlacz.textContent = licznik;
  }
});
