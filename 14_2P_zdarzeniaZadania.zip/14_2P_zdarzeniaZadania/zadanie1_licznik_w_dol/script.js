// 1. Zmienna licznik = 10
// 2. addEventListener click
// 3. licznik--
// 4. IF licznik == 0...
