# Ćwiczenie 1: Pasek nawigacji i semantyka

**Cel:** Zbudowanie strony zawierającej pasek nawigacyjny z nazwą kawiarni i trzema odnośnikami oraz stopkę, z wykorzystaniem semantycznych tagów HTML5.

**Scenariusz:** Tworzysz stronę główną dla nowo otwartej Kawiarni "Aroma". Potrzebny jest elegancki pasek nawigacyjny, główne powitanie oraz prosta stopka informacyjna.

**Wymagania:**
1. Ustaw tytuł strony na "Kawiarnia Aroma — Start".
2. Dodaj pasek nawigacyjny z nazwą marki "Kawiarnia Aroma" oraz trzema linkami: Start, Menu, Kontakt.
3. Pasek nawigacyjny powinien mieć ciemne tło i jasny tekst.
4. Zastąp ogólne tagi `<div>` odpowiednimi znacznikami semantycznymi, takimi jak `<nav>`, `<main>`, `<footer>`.
5. W głównej części strony (wewnątrz tagu `<main>`) dodaj nagłówek pierwszego poziomu `<h1>` o treści "Witaj w Kawiarni Aroma".
6. Pod nagłówkiem umieść akapit zawierający krótki tekst powitalny.
7. Na dole strony dodaj stopkę zawierającą Twoje imię i nazwisko oraz aktualny rok.
8. Zmień kolor tła paska nawigacyjnego na brązowy/kawowy, korzystając z niestandardowej klasy CSS podanej w pliku ze stylami.

**Wskazówki:**
- Przejrzyj plik `komponenty.html` i zdecyduj, który komponent najlepiej nadaje się do stworzenia paska nawigacyjnego. Skopiuj jego kod i dostosuj do wymagań.
- Pamiętaj, aby plik ze stylami CSS był podpięty w odpowiednim miejscu po stylach Bootstrapa.

**Podgląd:**
Po wykonaniu zadania zobaczysz stronę z brązowym paskiem nawigacyjnym na górze, zawierającym nazwę kawiarni i linki. Poniżej na białym tle znajdzie się duże powitanie, a na samym dole strony - prosta stopka.
