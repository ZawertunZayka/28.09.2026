# Ćwiczenie 5: Komponenty interaktywne (JS)

**Cel:** Dodanie interaktywnych komponentów Bootstrap (wymagających skryptów JavaScript) do strony, w szczególności modala (wyskakującego okna) oraz akordeonu (zwijanej listy).

**Scenariusz:** Tworzysz stronę informacyjną dla Kawiarni "Aroma". Na stronie głównej godziny otwarcia wyświetlają się w wyskakującym oknie (modal), a często zadawane pytania (FAQ) zaprezentowane są w formie akordeonu.

**Wymagania:**
1. Ustaw tytuł dokumentu w przeglądarce na "Kawiarnia Aroma — Informacje".
2. Na górze strony dodaj pasek nawigacyjny (`navbar`) z tzw. "hamburgerem" (przyciskiem rozwijającym menu na urządzeniach mobilnych). To Twoje pierwsze użycie klasy `navbar-expand-md` wraz ze znacznikiem przycisku przełączającego.
3. W sekcji głównej dodaj nagłówek poziomu pierwszego (`<h1>`) o treści "Informacje".
4. Pod nagłówkiem umieść responsywny obraz (banner/hero) wykorzystując klasę `img-fluid` oraz zewnętrzny adres URL z serwisu picsum.photos.
5. Poniżej wstaw przycisk "Godziny otwarcia", który po kliknięciu wyświetli wyskakujące okno (modal).
   - Wyskakujące okno powinno posiadać tytuł "Godziny otwarcia".
   - W głównym ciele modala umieść tabelę lub listę HTML z dniami i godzinami (Pon-Pt: 7:00-20:00, Sobota: 8:00-22:00, Niedziela: 9:00-18:00).
   - Okno modalne musi posiadać widoczny przycisk zamykający (X) w nagłówku.
6. Poniżej wstaw sekcję z odpowiedziami na pytania (FAQ) przy użyciu komponentu typu akordeon, który zawiera 3 elementy:
   - "Czy mogę przyjść z psem?" → "Tak, kawiarnia jest przyjazna zwierzętom, zapraszamy z pupilami."
   - "Czy macie Wi-Fi?" → "Tak, darmowe Wi-Fi jest dostępne. Hasło znajduje się na paragonie lub zapytaj obsługę."
   - "Czy można zarezerwować salę na imprezę?" → "Tak, nasza sala na piętrze mieści do 30 osób i idealnie nadaje się na imprezy okolicznościowe."
7. Zadbaj o to, aby pierwszy element akordeonu był domyślnie otwarty zaraz po załadowaniu strony.
8. Aby komponenty interaktywne poprawnie działały, przed znacznikiem zamykającym `</body>` umieść skrypt `bootstrap.bundle.min.js`.
9. Zastosuj semantyczne znaczniki HTML5 na stronie: użyj `<nav>` (dla nawigacji), `<main>` (dla głównej zawartości), `<section>` (dla sekcji z akordeonem FAQ) oraz `<footer>` (dla stopki informacyjnej).
10. Przetestuj pasek nawigacyjny i upewnij się, że poprawnie zwija się do ikony hamburgera na węższych ekranach oraz że rozwija się po jej kliknięciu.

**Wskazówki:**
- Znajdź gotowe struktury (szablony) w pliku `komponenty.html` udostępnionym wcześniej. Nie musisz pisać kodu tych skomplikowanych komponentów od zera.
- Modal wymaga prawidłowego dopasowania atrybutów `data-bs-target` na przycisku wywołującym z atrybutem `id` kontenera okna modalnego.

**Podgląd oczekiwanego efektu:**
Na stronie widoczny jest responsywny pasek nawigacyjny. Pod nim znajduje się powitanie oraz interaktywny przycisk wywołujący okienko z godzinami otwarcia. Poniżej przycisku mieści się czytelna lista rozwijana z informacjami FAQ, która domyślnie prezentuje pierwszą odpowiedź.
