# Ćwiczenie 4: Rozbudowany formularz i układ kolumnowy

## Cel
Budowa kompleksowego formularza kontaktowego/rezerwacyjnego, zawierającego różnorodne typy pól wejściowych, z zachowaniem zasad semantycznych i estetycznym centrowaniem.

## Scenariusz
Kawiarnia "Aroma" uruchamia usługę rezerwacji stolików online. Twoim zadaniem jest stworzenie podstrony z czytelnym i przejrzystym formularzem, który umożliwi klientom wpisanie wszystkich niezbędnych danych rezerwacyjnych.

## Wymagania
1. Przygotuj dokument HTML według wytycznych. Tytuł strony na karcie przeglądarki ma wynosić "Kawiarnia Aroma — Rezerwacja".
2. Umieść na górze strony pasek nawigacji analogiczny do poprzedniego ćwiczenia (marka "Kawiarnia Aroma", podstrony: Start, Menu, Kontakt) z ciemnobrązowym tłem ustalonym w pliku CSS za pomocą klasy `.tlo-nav`.
3. Pod nawigacją wstaw główny nagłówek strony `<h1>` o treści "Zarezerwuj stolik".
4. Stwórz formularz do rezerwacji stolika, zawierający następujące pola, pamiętając, aby zachować odstępy pomiędzy kolejnymi elementami:
   - Imię i nazwisko (zwykłe pole tekstowe),
   - Email (pole typu email),
   - Telefon (pole typu tel),
   - Data rezerwacji (pole do wyboru daty),
   - Liczba osób (lista rozwijana z opcjami od 1 do 6),
   - Dodatkowe uwagi (wieloliniowe pole tekstowe - textarea),
   - Pole wyboru (checkbox) z tekstem "Zgadzam się na przetwarzanie danych",
   - Przycisk wysyłający (submit) z napisem "Zarezerwuj".
5. Każde pole musi posiadać wyraźną etykietę (`<label>`), która jest powiązana z odpowiadającym polem wejściowym poprzez atrybuty `for` oraz `id`.
6. Wykorzystaj właściwe semantycznie znaczniki: `<nav>` (dla nawigacji), `<main>` (jako kontener na główną treść), `<form>` (sam formularz) ze znacznikami `<fieldset>` oraz `<legend>` w celu odpowiedniego pogrupowania danych formularza, a także `<footer>` (stopka u dołu strony).
7. Cały formularz umieść w węższej kolumnie centralnej (np. zajmującej 6 lub 8 jednostek siatki) i wyśrodkuj na ekranie przy użyciu właściwych klas układu pomocniczego, aby uniknąć jego rozciągania na całą szerokość monitora.
8. Dodaj na dole ekranu stopkę z krótką notką o prawach autorskich (np. "© 2026 Kawiarnia Aroma").

## Wskazówki
- Przeanalizuj zbiór komponentów i odszukaj tam kod odpowiedzialny za formularze. Dowiesz się stamtąd, jak powinna wyglądać struktura elementu grupującego etykietę i pole wejściowe.
- Aby umieścić formularz w środkowej kolumnie, zamknij go najpierw w kontenerze, następnie w wierszu, a sam formularz w kolumnie o odpowiedniej szerokości, na przykład dodając do kolumny klasę odpowiednią dla centrowania zawartości przy siatce (np. offset lub auto-marginesy).
- Wykorzystaj znaczniki HTML5 takie jak `<fieldset>` i `<legend>` do wizualnego i semantycznego objęcia całego bloku formularza.

## Podgląd
Podstrona powinna wyglądać nowocześnie, prezentując centralnie umieszczony formularz. Wszystkie pola powinny mieć jednolity, elegancki wygląd i czytelne odstępy pomiędzy sekcjami wprowadzania danych.
