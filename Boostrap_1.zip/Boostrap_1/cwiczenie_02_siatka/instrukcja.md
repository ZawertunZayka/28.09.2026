# Ćwiczenie 2: Siatka i układ kolumnowy

**Cel:** Zbudowanie dwukolumnowego układu strony (główna treść i pasek boczny) wraz z nawigacją.

**Scenariusz:** Tworzysz podstronę "O nas" dla Kawiarni "Aroma". Z lewej strony ma znaleźć się główny opis historii lokalu, a z prawej - użyteczny pasek boczny z godzinami otwarcia.

**Wymagania:**
1. Ustaw tytuł strony na "Kawiarnia Aroma — O nas".
2. Na samej górze umieść pasek nawigacyjny (identyczny jak w ćwiczeniu 1: marka oraz 3 linki, ciemne tło).
3. Pod paskiem nawigacyjnym stwórz układ dwukolumnowy: szersza kolumna lewa (zajmująca 8 z 12 jednostek siatki) na główną treść oraz węższa kolumna prawa (4 z 12 jednostek) na pasek boczny.
4. W lewej kolumnie dodaj nagłówek "O nas" oraz dwa akapity tekstu opisującego kawiarnię.
5. W prawej kolumnie dodaj nagłówek "Godziny otwarcia" i listę z wypisanymi dniami tygodnia oraz godzinami.
6. Na wąskich ekranach (urządzenia mobilne) kolumny powinny układać się jedna pod drugą (podejście mobile-first). Szersza i węższa kolumna mają działać na większych ekranach.
7. Zastosuj semantyczne znaczniki: `<nav>`, `<main>` z sekcjami (`<section>` na główny opis, `<aside>` na pasek boczny) oraz `<footer>`.
8. Dodaj odpowiednie klasy Bootstrapa do zarządzania marginesami i odstępami (np. klasy `mt`, `mb`, `p`).

**Wskazówki:**
- Znajdź w pliku `komponenty.html` przykłady układu grid (siatki) i dostosuj klasy szerokości kolumn (np. `col-md-8`, `col-md-4`).
- Pamiętaj o znaczniku `<div class="container">` na zewnątrz siatki oraz `<div class="row">` dla utworzenia rzędu.

**Podgląd:**
Na dużym ekranie zobaczysz szeroką kolumnę z opisem po lewej i węższą z godzinami po prawej. Przy zwężaniu okna przeglądarki, prawa kolumna przeskoczy pod lewą, tworząc jeden ciągły blok tekstu idealny dla urządzeń mobilnych.
