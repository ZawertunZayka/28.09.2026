# Ćwiczenie 3: Karty produktów i siatka (Grid)

## Cel
Stworzenie responsywnego układu wyświetlającego trzy karty z propozycjami napojów oraz paska nawigacji, z wykorzystaniem odpowiednich klas układu siatki (Grid).

## Scenariusz
Kawiarnia "Aroma" potrzebuje podstrony prezentującej menu ze swoimi trzema specjalnościami. Sekcja menu musi dobrze wyglądać zarówno na telefonach komórkowych (karty jedna pod drugą), jak i na szerszych ekranach (karty w jednym rzędzie).

## Wymagania
1. Skopiuj szkielet dokumentu oraz niezbędne zasoby (np. plik stylów) dostarczone w plikach początkowych. Tytuł dokumentu w zakładce przeglądarki powinien brzmieć "Kawiarnia Aroma — Menu".
2. Na samej górze strony umieść pasek nawigacyjny. Pasek powinien zawierać nazwę marki "Kawiarnia Aroma" oraz linki: Start, Menu, Kontakt. Do stylowania tła nawigacji wykorzystaj dedykowaną klasę w CSS (`.tlo-nav`).
3. Pod paskiem nawigacyjnym dodaj nagłówek głównego stopnia `<h1>` o treści "Nasze specjalności".
4. Poniżej nagłówka umieść powiadomienie (alert) informujące o promocji: "Promocja! Kawa dnia -20%". Zastosuj odpowiedni wariant kolorystyczny pasujący do informacji o promocji (np. wyróżniający się, pozytywny).
5. Pod alertem utwórz sekcję zawierającą trzy karty z napojami. Na szerokich ekranach (od rozmiaru średniego - `md` w górę) karty powinny wyświetlać się w jednym rzędzie, natomiast na węższych ekranach powinny układać się jedna pod drugą.
6. Każda z trzech kart powinna zawierać nazwę napoju jako tytuł karty, krótki opis (tekst karty) oraz przycisk z napisem "Zamów".
7. Dodaj obrazek do każdej karty wykorzystując zewnętrzny serwis ze zdjęciami zastępczymi (picsum.photos). Obrazek powinien znajdować się na samej górze karty (nad jej ciałem). Wykorzystaj wzorzec `card-img-top` z pliku `komponenty.html`.
8. Przyciski "Zamów" w każdej z trzech kart muszą mieć inny, unikalny wariant kolorystyczny z palety klas pomocniczych (np. podstawowy, sukces, ostrzeżenie).
9. Na dole strony umieść stopkę zawierającą informację o prawach autorskich (np. "© 2026 Kawiarnia Aroma").
10. Pamiętaj o użyciu semantycznych tagów HTML5: `<nav>` dla nawigacji, `<main>` dla głównej zawartości, `<section>` jako obwoluta dla obszaru kart, `<article>` jako obudowa dla każdej pojedynczej karty oraz `<footer>` dla stopki.

## Wskazówki
- Przejrzyj plik `komponenty.html`, aby odnaleźć odpowiednie fragmenty kodu dla paska nawigacji, komunikatów, układu siatki i kart.
- Aby karty układały się w rzędzie na większych ekranach i spadały pod siebie na małych, wykorzystaj system siatki i klasy responsywne (wiersze i kolumny o odpowiednich breakpointach).
- Zawartość nagłówka, alertu i kart powinna znaleźć się wewnątrz głównego kontenera, który zapewni marginesy na brzegach ekranu.

## Podgląd
Podstrona z menu powinna prezentować responsywny układ z wyraźnie wyodrębnionymi sekcjami. Karty z napojami stanowią centralny punkt interfejsu, zachęcając różnokolorowymi przyciskami do zamówienia.
