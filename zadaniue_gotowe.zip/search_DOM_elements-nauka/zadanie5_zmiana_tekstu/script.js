// Autor: Oleksii Klufinskyi
// Zadanie 5 – Zmiana tekstu: textContent i innerHTML

// KROK 1 – Odczyt i zmiana textContent
const tytul = document.querySelector("#tytul");
console.log(tytul.textContent);
tytul.textContent = "Zmiana tekstu w JavaScript";

// KROK 2 – textContent vs innerHTML
const demoTekst = document.querySelector("#demo-tekst");
demoTekst.textContent = "Tekst z <em>kursywą</em>";
// Efekt: na stronie widać dosłownie znaki <em> i </em>, bo textContent
// traktuje wszystko jako zwykły tekst.

demoTekst.innerHTML = "Tekst z <em>kursywą</em>";
// Efekt: słowo "kursywą" jest pochylone, bo innerHTML interpretuje tagi HTML.
// Różnica: textContent wstawia czysty tekst, innerHTML wstawia kod HTML.

// KROK 3 – Budowanie treści HTML przez innerHTML
const listaWynikow = document.querySelector("#lista-wynikow");
listaWynikow.innerHTML =
  "<ul><li>Wynik 1 – 85 punktów</li><li>Wynik 2 – 92 punkty</li><li>Wynik 3 – 78 punktów</li></ul>";

// KROK 4 – Powitanie (odczyt z formularza)
const poleImienia = document.querySelector("#pole-imienia");
const btnPrzywitaj = document.querySelector("#btn-przywitaj");
const powitanie = document.querySelector("#powitanie");

btnPrzywitaj.addEventListener("click", () => {
  const imie = poleImienia.value.trim();
  if (imie === "") {
    powitanie.textContent = "Najpierw wpisz swoje imię!";
  } else {
    powitanie.textContent = "Cześć, " + imie + "!";
  }
});

// KROK 5 – Licznik kliknięć
const licznikSpan = document.querySelector("#licznik");
const btnDodaj = document.querySelector("#btn-dodaj");
let licznik = 0;

btnDodaj.addEventListener("click", () => {
  licznik++;
  licznikSpan.textContent = licznik;
});
