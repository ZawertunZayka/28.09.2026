// Autor: Oleksii Klufinskyi
// Zadanie 3 – querySelector() z różnymi selektorami CSS

// KROK 1 – Selektor po id i po tagu
const glownyNaglowek = document.querySelector("#glowny-naglowek");
glownyNaglowek.textContent = "querySelector w akcji";

const pierwszyParagraf = document.querySelector("p");
pierwszyParagraf.style.color = "#8e44ad";

// KROK 2 – Selektor po klasie
const baner = document.querySelector(".baner");
baner.style.backgroundColor = "#16a085";

const banerSpan = document.querySelector(".baner span");
banerSpan.textContent = "Nowy tekst w banerze";

// KROK 3 – Selektor zagnieżdżony
const menuLi = document.querySelector(".menu li");
menuLi.style.color = "#f1c40f";

const menuLiDziecko = document.querySelector("ul.menu > li");
console.log(menuLi);
console.log(menuLiDziecko);
console.log("Ten sam element?", menuLi === menuLiDziecko); // true

// KROK 4 – Selektor po atrybucie
const poleTekst = document.querySelector("input[type='text']");
poleTekst.placeholder = "Wpisz swoje imię i nazwisko";

const produktVip = document.querySelector("[data-typ='vip']");
produktVip.style.backgroundColor = "gold";

// KROK 5 – Pseudoklasy CSS
const pierwszyProdukt = document.querySelector(".produkty li:first-child");
pierwszyProdukt.style.color = "#c0392b";

const ostatniProdukt = document.querySelector(".produkty li:last-child");
ostatniProdukt.style.backgroundColor = "#aed6f1";

const drugiProdukt = document.querySelector(".produkty li:nth-child(2)");
drugiProdukt.style.fontWeight = "bold";

// KROK 6 – Wyszukiwanie wewnątrz elementu
const profil = document.querySelector(".profil");

const profilNaglowek = profil.querySelector("h2");
profilNaglowek.textContent = "Oleksii Klufinskyi";

const profilOpis = profil.querySelector("p");
profilOpis.style.color = "#27ae60";
