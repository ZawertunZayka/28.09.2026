// Autor: Oleksii Klufinskyi
// Zadanie 7 – Interaktywny panel produktów

// KROK 1 – Wyszukiwanie i wypisywanie elementów
const karty = document.querySelectorAll(".karta");
console.log("Liczba kart:", karty.length);
karty.forEach((karta) => {
  console.log(karta.querySelector("h2").textContent);
});

// --- Aktualizacja licznika koszyka ---
const licznikKoszyka = document.getElementById("licznik-koszyka");

function aktualizujLicznik() {
  const ileWKoszyku = document.querySelectorAll(".karta.w-koszyku").length;
  licznikKoszyka.textContent = ileWKoszyku;
}

// Ustawia tekst przycisku zależnie od tego, czy karta jest w koszyku
function aktualizujPrzycisk(karta) {
  const przycisk = karta.querySelector(".btn-koszyk");
  if (karta.classList.contains("w-koszyku")) {
    przycisk.textContent = "✓ W koszyku";
  } else {
    przycisk.textContent = "Dodaj do koszyka";
  }
}

// KROK 2 – Przycisk "Dodaj do koszyka"
const przyciskiKoszyka = document.querySelectorAll(".btn-koszyk");

przyciskiKoszyka.forEach((przycisk) => {
  przycisk.addEventListener("click", () => {
    const karta = przycisk.closest(".karta");
    karta.classList.toggle("w-koszyku");
    aktualizujPrzycisk(karta);
    aktualizujLicznik();
  });
});

// KROK 3 – Filtrowanie wg kategorii
const btnWszystkie = document.getElementById("btn-wszystkie");
const btnElektronika = document.getElementById("btn-elektronika");
const btnAkcesoria = document.getElementById("btn-akcesoria");
const przyciskiFiltrow = [btnWszystkie, btnElektronika, btnAkcesoria];

function filtrujKarty(kategoria, aktywnyPrzycisk) {
  karty.forEach((karta) => {
    if (kategoria === "wszystkie" || karta.dataset.kategoria === kategoria) {
      karta.style.display = "";
    } else {
      karta.style.display = "none";
    }
  });

  przyciskiFiltrow.forEach((btn) => btn.classList.remove("aktywny-filtr"));
  aktywnyPrzycisk.classList.add("aktywny-filtr");
}

btnWszystkie.addEventListener("click", () => filtrujKarty("wszystkie", btnWszystkie));
btnElektronika.addEventListener("click", () => filtrujKarty("elektronika", btnElektronika));
btnAkcesoria.addEventListener("click", () => filtrujKarty("akcesoria", btnAkcesoria));

// KROK 4 – Zaznacz wszystkie / Odznacz wszystkie
const btnZaznaczWszystko = document.getElementById("btn-zaznacz-wszystko");
const btnOdznaczWszystko = document.getElementById("btn-odznacz-wszystko");

btnZaznaczWszystko.addEventListener("click", () => {
  karty.forEach((karta) => {
    karta.classList.add("w-koszyku");
    aktualizujPrzycisk(karta);
  });
  aktualizujLicznik();
});

btnOdznaczWszystko.addEventListener("click", () => {
  karty.forEach((karta) => {
    karta.classList.remove("w-koszyku");
    aktualizujPrzycisk(karta);
  });
  aktualizujLicznik();
});
