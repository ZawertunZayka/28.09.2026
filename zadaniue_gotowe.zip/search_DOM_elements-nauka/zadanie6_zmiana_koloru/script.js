// Autor: Oleksii Klufinskyi
// Zadanie 6 – Zmiana kolorów: style inline i classList

// KROK 1 – Styl inline (#panel-inline)
const panelInline = document.querySelector("#panel-inline");
panelInline.style.color = "white";
panelInline.style.backgroundColor = "#8e44ad";
panelInline.style.border = "3px solid #5b2c6f";

// KROK 2 – Wiele elementów (forEach + style)
const bloki = document.querySelectorAll(".blok");
bloki.forEach((blok) => {
  blok.style.backgroundColor = "#f39c12";
  blok.style.color = "white";
});

// KROK 3 – Tryb ciemny (classList.toggle)
const btnDark = document.querySelector("#btn-dark");
const strefaDark = document.querySelector("#strefa-dark");

btnDark.addEventListener("click", () => {
  strefaDark.classList.toggle("dark-mode");
});

// KROK 4 – Aktywna opcja (classList.add / remove)
const opcje = document.querySelectorAll(".opcja");

opcje.forEach((opcja) => {
  opcja.addEventListener("click", () => {
    opcje.forEach((o) => o.classList.remove("aktywna"));
    opcja.classList.add("aktywna");
  });
});

// KROK 5 – Warunkowa zmiana stanu (classList.contains)
const komunikat = document.querySelector("#komunikat");
const btnZmien = document.querySelector("#btn-zmien");

btnZmien.addEventListener("click", () => {
  if (komunikat.classList.contains("sukces")) {
    komunikat.classList.remove("sukces");
    komunikat.classList.add("blad");
    komunikat.textContent = "Status: błąd!";
  } else {
    komunikat.classList.add("sukces");
    komunikat.classList.remove("blad");
    komunikat.textContent = "Status: sukces!";
  }
});
