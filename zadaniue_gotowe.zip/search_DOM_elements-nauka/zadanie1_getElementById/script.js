// Autor: Oleksii Klufinskyi
// Zadanie 1 – Wyszukiwanie elementów po id (getElementById)

// KROK 1: Znajdź nagłówek i wypisz go w konsoli
const naglowek = document.getElementById("naglowek");
console.log(naglowek);

// KROK 2: Zmień tekst nagłówka
naglowek.textContent = "Moja pierwsza zmiana DOM";

// KROK 3: Znajdź akapit (id="opis") i zmień kolor jego tekstu
const opis = document.getElementById("opis");
opis.style.color = "#2980b9";

// KROK 4: Znajdź boks (id="boks") i zmień jego kolor tła
const boks = document.getElementById("boks");
boks.style.backgroundColor = "#fff3cd";

// KROK 5: Wyszukaj nieistniejący element (id="nieistniejacy")
const nieistniejacy = document.getElementById("nieistniejacy");
console.log(nieistniejacy);
// Wniosek: gdy element o takim id nie istnieje, getElementById zwraca null
// (nie wyrzuca błędu). Dopiero próba użycia null, np. nieistniejacy.textContent,
// spowodowałaby błąd, więc warto sprawdzić wynik przed użyciem.
