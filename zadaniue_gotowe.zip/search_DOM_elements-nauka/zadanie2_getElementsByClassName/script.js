// Autor: Oleksii Klufinskyi
// Zadanie 2 – getElementsByClassName

// KROK 1: Znajdź wszystkie karty (klasa "karta") i wypisz kolekcję w konsoli
const karty = document.getElementsByClassName("karta");
console.log(karty);
console.log("Liczba kart:", karty.length); // 5 elementów

// KROK 2: Pierwszy i ostatni element kolekcji
console.log("Pierwsza karta:", karty[0]);
console.log("Ostatnia karta:", karty[karty.length - 1]);

// KROK 3: Pętla for – zmień kolor tła wszystkich kart
for (let i = 0; i < karty.length; i++) {
  karty[i].style.backgroundColor = "#eaf2f8";
}

// KROK 4: Elementy z klasą "wyroznienie" – zmiana koloru tekstu
const wyrozniane = document.getElementsByClassName("wyroznienie");
console.log("Liczba wyróżnionych:", wyrozniane.length); // 2 elementy
for (let i = 0; i < wyrozniane.length; i++) {
  wyrozniane[i].style.color = "#c0392b";
}

// KROK 5: Konwersja kolekcji do tablicy i forEach
// Numer dopisuję do nagłówka h2 karty, żeby nie skasować reszty zawartości
// (ustawienie textContent na całej karcie usunęłoby h2 i p)
const kartyTablica = Array.from(document.getElementsByClassName("karta"));
kartyTablica.forEach((karta, index) => {
  karta.querySelector("h2").textContent += " [nr: " + index + "]";
});
