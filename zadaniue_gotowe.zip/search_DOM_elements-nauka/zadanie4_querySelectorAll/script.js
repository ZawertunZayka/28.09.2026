// Autor: Oleksii Klufinskyi
// Zadanie 4 – querySelectorAll() z różnymi selektorami CSS

// KROK 1 – Wszystkie paragrafy <p>
const paragrafy = document.querySelectorAll("p");
console.log(paragrafy);
console.log("Liczba paragrafów:", paragrafy.length);
paragrafy.forEach((p) => {
  p.style.color = "#34495e";
});

// KROK 2 – Elementy po klasie "wiersz"
const wiersze = document.querySelectorAll(".wiersz");
console.log("Liczba wierszy:", wiersze.length); // 5
wiersze.forEach((wiersz) => {
  wiersz.style.backgroundColor = "#fdebd0";
});

// KROK 3 – "Zebra stripes" w tabeli
const nieparzyste = document.querySelectorAll("table tr:nth-child(odd)");
nieparzyste.forEach((tr) => {
  tr.style.backgroundColor = "#d6eaf8";
});

const parzyste = document.querySelectorAll("table tr:nth-child(even)");
parzyste.forEach((tr) => {
  tr.style.backgroundColor = "#fcf3cf";
});

// KROK 4 – Selektor po atrybucie data-*
const zPriorytetem = document.querySelectorAll("[data-priorytet]");
console.log(zPriorytetem); // 3 elementy

const wysokiPriorytet = document.querySelectorAll("[data-priorytet='wysoki']");
wysokiPriorytet.forEach((el) => {
  el.style.border = "2px solid #e74c3c";
});

// KROK 5 – Lista selektorów (operator ,)
const kategorie = document.querySelectorAll(".kategoria-a, .kategoria-b");
console.log("Liczba elementów kategoria-a/b:", kategorie.length); // 5
kategorie.forEach((el) => {
  el.style.color = "#1a5276";
});

// KROK 6 – Bezpośrednie dzieci (>)
const dzieciListy = document.querySelectorAll("ul#glowna-lista > li");
console.log("Bezpośrednie dzieci listy:", dzieciListy.length); // 4
dzieciListy.forEach((li) => {
  li.style.color = "#117a65";
});
// Zagnieżdżone li z .podlista NIE zostały wybrane, bo nie są bezpośrednimi
// dziećmi ul#glowna-lista (są dziećmi ul.podlista).
// Uwaga: kolor jest dziedziczony, więc tekst podlisty wygląda tak samo,
// ale selektor ich nie zwrócił.

// KROK 7 – Konwersja NodeList na tablicę + filter()
const produkty = document.querySelectorAll(".produkt");
const produktyTablica = Array.from(produkty);
const produktyVip = produktyTablica.filter((p) => p.textContent.includes("VIP"));
console.log(produktyVip); // 3 produkty
