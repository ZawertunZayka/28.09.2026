// Autor: Oleksii Klufinskyi
const poleImie = document.querySelector("#nameInput");
const podglad = document.querySelector("#namePreview");

poleImie.addEventListener("input", (e) => {
  const wartosc = e.target.value;
  if (wartosc.trim() === "") {
    podglad.textContent = "Jan Nowak";
  } else {
    podglad.textContent = wartosc;
  }
});
