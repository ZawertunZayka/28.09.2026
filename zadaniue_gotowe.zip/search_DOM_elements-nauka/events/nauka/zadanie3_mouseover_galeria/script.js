// Autor: Oleksii Klufinskyi
const boxy = document.querySelectorAll(".box");
const info = document.querySelector("#info");

boxy.forEach((box) => {
  box.addEventListener("mouseenter", () => {
    box.style.backgroundColor = "yellow";
    info.textContent = box.dataset.opis;
  });

  box.addEventListener("mouseleave", () => {
    box.style.backgroundColor = "";
    info.textContent = "Najedź na element";
  });
});
