// Autor: Oleksii Klufinskyi
const przycisk = document.querySelector("#changeBtn");
const tekst = document.querySelector("#text");

przycisk.addEventListener("click", function () {
  tekst.textContent = "Tekst został zmieniony!";
  document.body.style.backgroundColor = "lightblue";
});
