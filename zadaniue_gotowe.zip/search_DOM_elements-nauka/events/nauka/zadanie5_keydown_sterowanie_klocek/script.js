// Autor: Oleksii Klufinskyi
const player = document.querySelector("#player");

let x = 0;
let y = 0;
const krok = 10;
const maxPozycja = 350; // plansza 400px - kropka 50px

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowRight") {
    x += krok;
  } else if (e.key === "ArrowLeft") {
    x -= krok;
  } else if (e.key === "ArrowUp") {
    y -= krok;
  } else if (e.key === "ArrowDown") {
    y += krok;
  } else {
    return;
  }

  // kropka nie wychodzi poza planszę
  x = Math.max(0, Math.min(maxPozycja, x));
  y = Math.max(0, Math.min(maxPozycja, y));

  e.preventDefault(); // strzałki nie przewijają strony
  player.style.transform = "translate(" + x + "px, " + y + "px)";
});
