// Pobranie elementów drzewa DOM
const inputImie = document.querySelector('#imie');
const inputEmail = document.querySelector('#email');
const komImie = document.querySelector('#komunikat-imie');
const komEmail = document.querySelector('#komunikat-email');
const btnZapisz = document.querySelector('#btn-zapisz');
const podsumowanie = document.querySelector('#podsumowanie');

// Twoje rozwiazanie:
// 1. Zarejestruj zdarzenie 'input' na polu inputImie:
//    - jeśli wartość ma mniej niż 3 znaki:
//        dodaj 'blad-walidacji', usuń 'sukces-walidacji', komImie.textContent = 'Błąd: Imię musi zawierać co najmniej 3 znaki!'
//    - w przeciwnym razie:
//        usuń 'blad-walidacji', dodaj 'sukces-walidacji', wyczyść komImie.textContent = ''
inputImie.addEventListener('input', () => {
  // TODO: walidacja pola imienia
});

// 2. Zarejestruj zdarzenie 'input' na polu inputEmail:
//    - jeśli wartość nie zawiera znaku '@' (użyj !inputEmail.value.includes('@')):
//        dodaj 'blad-walidacji', usuń 'sukces-walidacji', komEmail.textContent = 'Błąd: Wprowadź poprawny adres e-mail ze znakiem @!'
//    - w przeciwnym razie:
//        usuń 'blad-walidacji', dodaj 'sukces-walidacji', wyczyść komEmail.textContent = ''
inputEmail.addEventListener('input', () => {
  // TODO: walidacja pola e-mail
});

// 3. Zarejestruj zdarzenie 'click' na btnZapisz:
//    - sprawdź za pomocą classList.contains('sukces-walidacji'), czy oba pola są poprawne
//    - jeśli tak: podsumowanie.textContent = 'Formularz poprawny. Dziękujemy za dołączenie do klubu Zielony Ogród!'
//    - jeśli nie: podsumowanie.textContent = 'Błąd: Popraw zaznaczone pola przed wysłaniem!'
btnZapisz.addEventListener('click', () => {
  // TODO: weryfikacja gotowości formularza
});
