// Pobranie kolekcji przycisków zakładek i paneli treści
const przyciski = document.querySelectorAll('.tab-btn');
const panele = document.querySelectorAll('.tab-panel');

// Twoje rozwiazanie:
// Za pomocą pętli przyciski.forEach zarejestruj zdarzenie click na każdym przycisku:
// 1. Usuń klasę 'aktywny' ze wszystkich przycisków w kolekcji (użyj pętli przyciski.forEach)
// 2. Dodaj klasę 'ukryty' do wszystkich paneli w kolekcji (użyj pętli panele.forEach)
// 3. Dodaj klasę 'aktywny' do aktualnie klikniętego przycisku (użyj btn.classList.add('aktywny'))
// 4. Odczytaj atrybut data-cel klikniętego przycisku (btn.dataset.cel)
// 5. Pobierz odpowiadający mu panel: document.querySelector('#' + btn.dataset.cel)
// 6. Usuń klasę 'ukryty' ze znalezionego panelu
przyciski.forEach((btn) => {
  btn.addEventListener('click', () => {
    // TODO: uzupełnij logikę przełączania zakładek
  });
});
