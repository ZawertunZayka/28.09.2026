// Pobranie elementów drzewa DOM
const btnMotyw = document.querySelector('#btn-motyw');
const statusMotywu = document.querySelector('#status-motywu');

// Twoje rozwiazanie:
// Zarejestruj zdarzenie click na przycisku btnMotyw, które:
// 1. Przełączy klasę 'jasny-motyw' na elemencie document.body za pomocą classList.toggle('jasny-motyw')
// 2. Sprawdzi za pomocą document.body.classList.contains('jasny-motyw'), czy motyw jasny jest aktywny
// 3. Jeśli klasa 'jasny-motyw' występuje:
//    - btnMotyw.textContent = 'Przełącz na ciemny motyw'
//    - statusMotywu.textContent = 'Aktualny motyw: Dzienny (jasny)'
// 4. Jeśli klasy 'jasny-motyw' brak:
//    - btnMotyw.textContent = 'Przełącz na jasny motyw'
//    - statusMotywu.textContent = 'Aktualny motyw: Nocny (ciemny)'
btnMotyw.addEventListener('click', () => {
  // TODO: uzupełnij kod przełączania motywu strony
});
