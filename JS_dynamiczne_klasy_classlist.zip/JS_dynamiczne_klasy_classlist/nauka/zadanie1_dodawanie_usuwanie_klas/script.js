// Pobranie elementów drzewa DOM
const baner = document.querySelector('#baner-promocji');
const btnAktywuj = document.querySelector('#btn-aktywuj');
const btnDezaktywuj = document.querySelector('#btn-dezaktywuj');
const komunikat = document.querySelector('#komunikat-status');

// Twoje rozwiazanie:
// 1. Zarejestruj zdarzenie click na przycisku btnAktywuj, które:
//    - doda klasę 'aktywny' do elementu baner za pomocą classList.add()
//    - ustawi textContent komunikatu na: 'Wyróżnienie promocyjne zostało włączone.'
btnAktywuj.addEventListener('click', () => {
  // TODO: uzupełnij kod dodawania klasy
});

// 2. Zarejestruj zdarzenie click na przycisku btnDezaktywuj, które:
//    - usunie klasę 'aktywny' z elementu baner za pomocą classList.remove()
//    - ustawi textContent komunikatu na: 'Wyróżnienie promocyjne zostało wyłączone.'
btnDezaktywuj.addEventListener('click', () => {
  // TODO: uzupełnij kod usuwania klasy
});
