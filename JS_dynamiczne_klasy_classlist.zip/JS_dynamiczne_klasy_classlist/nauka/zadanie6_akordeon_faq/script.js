// Pobranie kolekcji przycisków pytań
const pytania = document.querySelectorAll('.faq-pytanie');

// Twoje rozwiazanie:
// Za pomocą pętli forEach podepnij zdarzenie click pod każdy przycisk pytania:
// 1. Znajdź nadrzędny element kontenera pytania za pomocą btn.closest('.faq-element')
// 2. Przełącz na nim klasę 'otwarty' za pomocą kontener.classList.toggle('otwarty')
pytania.forEach((btn) => {
  btn.addEventListener('click', () => {
    // TODO: uzupełnij kod przełączania akordeonu
  });
});
