// Pobranie elementów drzewa DOM
const btnSzczegoly = document.querySelector('#btn-szczegoly');
const panelSzczegoly = document.querySelector('#szczegoly-naprawy');

// Twoje rozwiazanie:
// Zarejestruj zdarzenie click na przycisku btnSzczegoly, które:
// 1. Przełączy klasę 'ukryty' na elemencie panelSzczegoly za pomocą classList.toggle('ukryty')
// 2. Sprawdzi, czy element panelSzczegoly posiada obecnie klasę 'ukryty' (np. metodą classList.contains('ukryty'))
// 3. Jeśli klasa 'ukryty' występuje -> ustawi textContent przycisku na: 'Pokaż szczegóły techniczne'
// 4. Jeśli klasy 'ukryty' nie ma -> ustawi textContent przycisku na: 'Ukryj szczegóły techniczne'
btnSzczegoly.addEventListener('click', () => {
  // TODO: uzupełnij kod przełączania widoczności i tekstu przycisku
});
