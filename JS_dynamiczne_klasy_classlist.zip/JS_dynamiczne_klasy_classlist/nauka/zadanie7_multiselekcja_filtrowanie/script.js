// Pobranie elementów drzewa DOM
const kartyProduktow = document.querySelectorAll('.karta-produktu');
const przyciskiFiltrow = document.querySelectorAll('.btn-filtr');
const btnOdznacz = document.querySelector('#btn-odznacz');
const podsumowanie = document.querySelector('#podsumowanie');

// Funkcja pomocnicza aktualizująca licznik zaznaczonych pozycji
function aktualizujLicznik() {
  const ileZaznaczonych = document.querySelectorAll('.karta-produktu.zaznaczony').length;
  podsumowanie.textContent = `Liczba zaznaczonych produktów: ${ileZaznaczonych} szt.`;
}

// Twoje rozwiazanie:
// 1. Dla każdej karty w kolekcji kartyProduktow podepnij zdarzenie click:
//    - przełącz klasę 'zaznaczony' za pomocą karta.classList.toggle('zaznaczony')
//    - wywołaj funkcję aktualizujLicznik()
kartyProduktow.forEach((karta) => {
  karta.addEventListener('click', () => {
    // TODO: obsługa kliknięcia produktu
  });
});

// 2. Dla każdego przycisku w kolekcji przyciskiFiltrow podepnij zdarzenie click:
//    - usuń klasę 'aktywny' ze wszystkich przycisków i dodaj ją do klikniętego
//    - odczytaj kategorię wybraną w filtrze: const kat = btn.dataset.kategoria
//    - przeiteruj po kartach produktów i steruj klasą 'ukryty':
//        jeśli kat === 'wszystkie' lub karta.dataset.kategoria === kat -> usuń 'ukryty'
//        w przeciwnym razie -> dodaj 'ukryty'
przyciskiFiltrow.forEach((btn) => {
  btn.addEventListener('click', () => {
    // TODO: obsługa filtrowania produktów
  });
});

// 3. Po kliknięciu btnOdznacz:
//    - usuń klasę 'zaznaczony' ze wszystkich kart
//    - wywołaj aktualizujLicznik()
btnOdznacz.addEventListener('click', () => {
  // TODO: obsługa odznaczania
});
