// Pobranie elementów drzewa DOM zgodnie z kontraktem
const menuBoczne = document.querySelector('#menu-boczne');
const btnMenu = document.querySelector('#btn-menu');
const btnMotyw = document.querySelector('#btn-motyw');
const inputImie = document.querySelector('#imie');
const inputEmail = document.querySelector('#email');
const selectUsluga = document.querySelector('#usluga');
const inputIlosc = document.querySelector('#ilosc');
const checkRegulamin = document.querySelector('#regulamin');
const btnZamow = document.querySelector('#btn-zamow');
const btnReset = document.querySelector('#btn-reset');
const komunikatStatus = document.querySelector('#komunikat-status');
const podsumowanie = document.querySelector('#podsumowanie');

// Twoje rozwiazanie:
// 1. Zarejestruj zdarzenie click na btnMenu, które przełączy klasę 'otwarty' na menuBoczne
btnMenu.addEventListener('click', () => {
  // TODO: przełączanie panelu bocznego
});

// 2. Zarejestruj zdarzenie click na btnMotyw, które przełączy klasę 'ciemny-motyw' na document.body
btnMotyw.addEventListener('click', () => {
  // TODO: przełączanie motywu
});

// 3. Zarejestruj zdarzenie click na btnZamow:
//    - sprawdź, czy inputImie.value.trim().length >= 3 oraz inputEmail.value.includes('@')
//    - jeśli pole jest błędne: dodaj 'blad-walidacji', usuń 'sukces-walidacji'
//    - jeśli pole jest poprawne: usuń 'blad-walidacji', dodaj 'sukces-walidacji'
//    - sprawdź czy checkRegulamin.checked jest zaznaczony; jeśli nie: komunikatStatus.textContent = 'Wymagana akceptacja regulaminu!'
//    - jeśli formularz jest w 100% poprawny:
//        oblicz łączny koszt = Number(selectUsluga.value) * Number(inputIlosc.value)
//        podsumowanie.textContent = `Wycena gotowa. Łączny koszt zamówienia brutto: ${koszt} zł`
//        usuń klasę 'ukryty' z elementu podsumowanie
btnZamow.addEventListener('click', () => {
  // TODO: obsługa walidacji i wyceny
});

// 4. Zarejestruj zdarzenie click na btnReset:
//    - wyczyść wartości pól formularza
//    - usuń klasy 'blad-walidacji' i 'sukces-walidacji'
//    - dodaj klasę 'ukryty' do podsumowanie i wyczyść komunikatStatus
btnReset.addEventListener('click', () => {
  // TODO: reset formularza i stylów
});
