// Twoje rozwiazanie

const termin = document.querySelector("#termin");
const cena = document.querySelector("#cena");
const regulamin = document.querySelector("#regulamin");
const rezerwuj = document.querySelector("#rezerwuj");
const komunikat = document.querySelector("#status");

const TEKST_STARTOWY = "Wybierz termin.";

function pobierzCene() {
  const opcja = termin.options[termin.selectedIndex];
  return opcja.getAttribute("data-cena");
}

termin.addEventListener("change", () => {
  if (termin.value === "") {
    cena.textContent = TEKST_STARTOWY;
  } else {
    cena.textContent = pobierzCene();
  }
});

regulamin.addEventListener("change", () => {
  if (regulamin.checked) {
    rezerwuj.removeAttribute("disabled");
  } else {
    rezerwuj.setAttribute("disabled", "");
  }
});

rezerwuj.addEventListener("click", () => {
  if (termin.value === "") {
    komunikat.textContent = TEKST_STARTOWY;
    return;
  }

  const nazwa = termin.options[termin.selectedIndex].textContent;
  komunikat.textContent = `Zarezerwowano: ${nazwa} (${pobierzCene()})`;
});
