// Twoje rozwiazanie

const pole = document.querySelector("#budget");
const przycisk = document.querySelector("#filter-btn");
const produkty = document.querySelectorAll(".product");

przycisk.addEventListener("click", () => {
  const budzet = Number(pole.value);

  produkty.forEach((produkt) => {
    const cena = Number(produkt.getAttribute("data-price"));

    if (cena > budzet) {
      produkt.setAttribute("hidden", "");
    } else {
      produkt.removeAttribute("hidden");
    }
  });
});
