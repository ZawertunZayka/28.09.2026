// Twoje rozwiazanie

const obraz = document.querySelector("#main-image");
const przyciski = document.querySelectorAll(".btn");

przyciski.forEach((przycisk) => {
  przycisk.addEventListener("click", () => {
    const adres = przycisk.getAttribute("data-src");
    obraz.setAttribute("src", adres);
    obraz.setAttribute("alt", przycisk.textContent.trim());
  });
});
