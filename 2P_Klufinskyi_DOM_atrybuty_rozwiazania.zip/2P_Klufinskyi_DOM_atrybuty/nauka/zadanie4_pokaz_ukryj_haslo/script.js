// Twoje rozwiazanie

const haslo = document.querySelector("#password");
const przycisk = document.querySelector("#toggle-btn");

przycisk.addEventListener("click", () => {
  if (haslo.getAttribute("type") === "password") {
    haslo.setAttribute("type", "text");
    przycisk.setAttribute("title", "Ukryj hasło");
  } else {
    haslo.setAttribute("type", "password");
    przycisk.setAttribute("title", "Pokaż hasło");
  }
});
