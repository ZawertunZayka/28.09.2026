// Twoje rozwiazanie

const przycisk = document.querySelector("#edit-btn");
const pola = document.querySelectorAll("#profile-form input");

przycisk.addEventListener("click", () => {
  pola.forEach((pole) => {
    pole.toggleAttribute("disabled");
  });

  const edytowalne = !pola[0].hasAttribute("disabled");
  przycisk.textContent = edytowalne ? "Zapisz Zmiany" : "Edytuj Dane";
});
