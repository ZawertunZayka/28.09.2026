// Twoje rozwiazanie

const przycisk = document.querySelector("#process-btn");
const linki = document.querySelectorAll(".link-list a");

przycisk.addEventListener("click", () => {
  linki.forEach((link) => {
    const href = link.getAttribute("href");

    if (href.startsWith("http")) {
      link.setAttribute("target", "_blank");
      link.setAttribute("title", "Otworzy się w nowej karcie");
      link.setAttribute("data-external", "true");
    }
  });
});
