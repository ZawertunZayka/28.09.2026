// Twoje rozwiazanie

const wyslij = document.querySelector("#submit-btn");
const odblokuj = document.querySelector("#unlock-btn");

odblokuj.addEventListener("click", () => {
  if (wyslij.hasAttribute("disabled")) {
    wyslij.removeAttribute("disabled");
  }
});
