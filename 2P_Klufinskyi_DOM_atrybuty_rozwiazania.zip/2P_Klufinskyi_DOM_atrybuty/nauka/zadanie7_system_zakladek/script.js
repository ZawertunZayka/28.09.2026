// Twoje rozwiazanie

const przyciski = document.querySelectorAll(".tab-btn");
const panele = document.querySelectorAll(".tab-content");

przyciski.forEach((przycisk) => {
  przycisk.addEventListener("click", () => {
    const cel = przycisk.getAttribute("data-target");

    panele.forEach((panel) => {
      panel.setAttribute("hidden", "");
    });
    document.getElementById(cel).removeAttribute("hidden");

    przyciski.forEach((p) => {
      p.setAttribute("aria-selected", "false");
    });
    przycisk.setAttribute("aria-selected", "true");
  });
});
